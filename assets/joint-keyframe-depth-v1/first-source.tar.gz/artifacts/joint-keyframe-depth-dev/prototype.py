"""Bounded joint/fixed keyframe-pose experiment; no reference labels in fitting."""
import importlib.util
import io
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from projective_depth_common import CAMERA, exp_rotation, require, sha, write
from projective_depth_raw import pyramid


def pair(target, source, target_pose, source_pose, scale):
    stride = {4:1,2:2,1:4}[scale]
    a,b = target['surface'][scale],source['surface'][scale]
    xyz = b['vertices'][::stride,::stride].reshape(-1,3)
    normal = b['normals'][::stride,::stride].reshape(-1,3)
    keep = np.sum(normal*normal,axis=1) > .25
    xyz,normal = xyz[keep],normal[keep]
    q = xyz@source_pose[:3,:3].T+source_pose[:3,3]
    normal = normal@source_pose[:3,:3].T
    local = (q-target_pose[:3,3])@target_pose[:3,:3]
    ids = np.flatnonzero(local[:,2] > .3)
    c = a['camera']
    u = np.rint(c['fx']*local[ids,0]/local[ids,2]+c['cx'])
    v = np.rint(c['fy']*local[ids,1]/local[ids,2]+c['cy'])
    inside = (u >= 1)&(u < c['width']-1)&(v >= 1)&(v < c['height']-1)
    ids,u,v = ids[inside],u[inside].astype(int),v[inside].astype(int)
    n = a['normals'][v,u]; nr = n@target_pose[:3,:3].T
    valid = ((np.sum(n*n,axis=1) > .25)
             &(np.linalg.norm(local[ids]-a['vertices'][v,u],axis=1) < (.12 if scale == 4 else .08))
             &(np.sum(normal[ids]*nr,axis=1) > .8))
    ids,n,nr,u,v = ids[valid],n[valid],nr[valid],u[valid],v[valid]
    r = np.sum(n*(local[ids]-a['vertices'][v,u]),axis=1)
    j = np.column_stack([nr,np.cross(q[ids],nr)])
    w = np.minimum(1.,.01/np.maximum(abs(r),1e-15))
    return len(r),float(r@r),j.T@(w[:,None]*j),j.T@(w*r)


def equation(nodes, poses, scale, mode):
    variable = list(range(1,len(nodes))) if mode == 'joint' else [len(nodes)-1]
    slots = {node:slice(6*k,6*k+6) for k,node in enumerate(variable)}
    h,g = np.zeros((len(variable)*6,len(variable)*6)),np.zeros(len(variable)*6)
    edges = []; squared = 0.; count = 0; graph = [set() for _ in nodes]
    for source in range(1,len(nodes)):
        for target in range(source):
            n,ss,hh,gg = pair(nodes[target],nodes[source],poses[target],poses[source],scale)
            if n < 200:
                continue
            edges.append(dict(target=target,source=source,count=n,rms_m=float(np.sqrt(ss/n))))
            graph[target].add(source);graph[source].add(target)
            count += n;squared += ss
            a,b = slots.get(target),slots.get(source)
            if a is not None:h[a,a] += hh;g[a] -= gg
            if b is not None:h[b,b] += hh;g[b] += gg
            if a is not None and b is not None:h[a,b] -= hh;h[b,a] -= hh
    connected = {0}
    while True:
        updated = connected.union(*(graph[k] for k in connected))
        if updated == connected:break
        connected = updated
    if len(connected) != len(nodes):raise ValueError('disconnected measured constraint graph')
    return h,g,edges,float(np.sqrt(squared/count)),variable


def fit(nodes, mode):
    poses = [n['root'].copy() for n in nodes]
    trace = []
    for scale,cap in [(4,10),(2,7),(1,5)]:
        for _ in range(cap):
            h,g,edges,rms,variable = equation(nodes,poses,scale,mode)
            diagonal = np.sqrt(np.diag(h))
            if not np.isfinite(diagonal).all() or np.any(diagonal <= 0):raise ValueError('zero diagonal')
            a = h/diagonal[:,None]/diagonal[None,:];eig = np.linalg.eigvalsh(a)
            if eig[0] <= 0 or eig[-1]/eig[0] > 1e6:raise ValueError('condition')
            d = (np.linalg.solve(a,-g/diagonal)/diagonal).reshape(-1,6)
            if any(np.linalg.norm(x[:3]) > .1 or np.linalg.norm(x[3:]) > .15 for x in d):raise ValueError('increment')
            before = [p.tolist() for p in poses]
            for node,delta in zip(variable,d):
                inc = np.eye(4);inc[:3,:3],inc[:3,3] = exp_rotation(delta[3:]),delta[:3]
                poses[node] = inc@poses[node]
            trace.append(dict(scale=scale,edges=edges,rms_m=rms,condition=float(eig[-1]/eig[0]),
                variable_nodes=variable,before=before,delta=d.tolist(),after=[p.tolist() for p in poses]))
            if all(np.linalg.norm(x[:3]) < 1e-5 and np.linalg.norm(x[3:]) < 1e-5 for x in d):break
    _,_,edges,rms,_ = equation(nodes,poses,1,mode)
    if rms > .03:raise ValueError('returned-pose global residual')
    return poses,trace,dict(edges=edges,rms_m=rms)


def operational(case,mode,out):
    base = ROOT/'data'/case;body = (base/'manifest.json').read_bytes();m = json.loads(body)
    frames = m['frames']; inventory = {v['file']:v for v in m['files']}
    def verified(name):
        b = (base/'raw'/name).read_bytes();pin = inventory[name]
        require(len(b) == pin['bytes'] and sha(b) == pin['sha256'],'source digest '+name)
        return b
    for name in inventory:verified(name)
    require(len(frames) == 180 and all(b['depth_timestamp'] > a['depth_timestamp'] for a,b in zip(frames,frames[1:])),
            'all chronological original acquisitions')
    sources = [Path(__file__),ROOT/'scripts/projective_depth_raw.py',ROOT/'scripts/projective_depth_common.py',
               ROOT/'scripts/check-opencv-rgbd.py',ROOT/'assets/joint-keyframe-depth-v1/design.json']
    write(out/'freeze.json',dict(mode=mode,manifest_sha256=sha(body),inputs=inventory,
        source_sha256={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sources},
        data_role='viewed development, not held out',ground_truth_operational=False,numpy_version=np.__version__))
    keys = [];latest = None;last = None;lost = False;rows = []
    for frame in frames:
        stamp = frame['depth_timestamp'];row = dict(source_index=frame['source_index'],timestamp=stamp,accepted=False)
        if last is not None and stamp-last > .2:lost = True
        try:
            if lost:raise ValueError('accepted pose expiry latched')
            image = Image.open(io.BytesIO(verified(frame['depth_file'])))
            require(image.size == (640,480) and image.mode in ('I;16','I;16B','I'),'bounded axial depth PNG')
            depth = np.asarray(image,dtype=float)/5000.
            current = dict(timestamp=stamp,surface=pyramid(depth,CAMERA),root=np.eye(4) if latest is None else latest['root'].copy())
            if latest is None:
                require(np.sum(np.sum(current['surface'][4]['normals']**2,axis=-1) > .25) >= 200,'initial support')
                keys = [current];latest = current;last = stamp
                row.update(accepted=True,root=np.eye(4).tolist(),nodes=[stamp],trace=[])
            else:
                nodes = list(keys)
                if latest not in nodes:nodes.append(latest)
                nodes.append(current);require(len(nodes) <= 5,'bounded window')
                roots,trace,final = fit(nodes,mode)
                relative = np.linalg.inv(latest['root'])@roots[-1]
                if np.linalg.norm(relative[:3,3]) > .5:raise ValueError('accepted displacement')
                delta = np.linalg.inv(roots[nodes.index(keys[-1])])@roots[-1]
                replace = np.linalg.norm(delta[:3,3]) > .1 or np.arccos(np.clip((np.trace(delta[:3,:3])-1)/2,-1,1)) > .1
                # Atomic commit: pose arrays were detached during all fitting/admission.
                for node,root in zip(nodes,roots):node['root'] = root
                if replace:keys = [keys[0],*keys[1:][-1:],current]
                latest = current;last = stamp
                row.update(accepted=True,root=roots[-1].tolist(),nodes=[n['timestamp'] for n in nodes],trace=trace,
                    final_equation=final,keyframe_replaced=bool(replace),revised_roots=[p.tolist() for p in roots])
        except ValueError as error:row['rejection'] = str(error)
        row.update(lost=lost,last_accepted_timestamp=last)
        rows.append(row)
        if len(rows)%30 == 0:print(case,mode,len(rows),flush=True)
    write(out/'sensor-only.json',dict(frames=rows,ground_truth_parsed=False))
    return frames,rows,verified


def main():
    output = ROOT/'artifacts/joint-keyframe-depth-dev/first';output.mkdir()
    saved = {}
    for case in ['tum-fr1-room-temporal','tum-fr1-desk2-independent']:
        for mode in ['fixed','joint']:
            name = case+'-'+mode;out = output/name;out.mkdir();saved[name] = operational(case,mode,out)
    spec = importlib.util.spec_from_file_location('physical_reference',ROOT/'scripts/check-opencv-rgbd.py')
    ref = importlib.util.module_from_spec(spec);spec.loader.exec_module(ref);ref.controls();summaries = {}
    for name,(frames,rows,verified) in saved.items():
        labels = np.loadtxt(io.BytesIO(verified('groundtruth.txt')),comments='#')
        require(labels.ndim == 2 and labels.shape[1] == 8 and np.isfinite(labels).all() and np.all(np.diff(labels[:,0]) > 0),'whole chronological reference')
        origin = np.linalg.inv(ref.truth_at(labels,frames[0]['depth_timestamp']));errors = []
        for frame,row in zip(frames[1:],rows[1:]):
            if not row['accepted']:continue
            estimate = np.asarray(row['root']);truth = origin@ref.truth_at(labels,frame['depth_timestamp'])
            p = float(np.linalg.norm(estimate[:3,3]-truth[:3,3]));a = float(np.arccos(np.clip((np.trace(truth[:3,:3].T@estimate[:3,:3])-1)/2,-1,1)))
            row.update(position_error_m=p,rotation_error_rad=a,accurate=p <= .1 and a <= .1);errors.append((p,a))
        summary = dict(total_updates=179,accepted=len(errors),root_accurate=sum(r.get('accurate',False) for r in rows),
            lost=rows[-1]['lost'],max_position_error_m=max((x[0] for x in errors),default=None),
            max_rotation_error_rad=max((x[1] for x in errors),default=None))
        summaries[name] = summary;write(output/name/'results.json',dict(summary=summary,frames=rows));print(name,json.dumps(summary),flush=True)
    write(output/'comparison.json',summaries)


if __name__ == '__main__':main()
