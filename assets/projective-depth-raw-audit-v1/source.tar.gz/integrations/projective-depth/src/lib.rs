//! Optical x-right/y-down/z-forward depths in metres. Research odometry only.
//! No images, reference poses, clocks supplied by wall time or driving controls.

use serde::{Deserialize, Serialize};

pub mod supervision;

type V = [f64; 3];
type M = [[f64; 3]; 3];
type H = [[f64; 6]; 6];
const MIN_Z: f64 = 0.3;
const MAX_Z: f64 = 5.0;
const MIN_SUPPORT: usize = 200;
const AGE: f64 = 0.2;

#[derive(Clone, Copy, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Camera {
    pub width: usize,
    pub height: usize,
    pub fx: f64,
    pub fy: f64,
    pub cx: f64,
    pub cy: f64,
}
impl Camera {
    pub fn validate(self) -> Result<(), String> {
        if !(32..=640).contains(&self.width)
            || !(32..=480).contains(&self.height)
            || !self.width.is_multiple_of(4)
            || !self.height.is_multiple_of(4)
            || ![self.fx, self.fy, self.cx, self.cy]
                .iter()
                .all(|v| v.is_finite())
            || !(20.0..=5000.0).contains(&self.fx)
            || !(20.0..=5000.0).contains(&self.fy)
            || !(0.0..self.width as f64).contains(&self.cx)
            || !(0.0..self.height as f64).contains(&self.cy)
        {
            return Err("invalid bounded pinhole camera".into());
        }
        Ok(())
    }
    fn scaled(self, scale: usize) -> Self {
        let s = scale as f64;
        Self {
            width: self.width / scale,
            height: self.height / scale,
            fx: self.fx / s,
            fy: self.fy / s,
            cx: (self.cx + 0.5) / s - 0.5,
            cy: (self.cy + 0.5) / s - 0.5,
        }
    }
    fn point(self, i: usize, z: f64) -> V {
        [
            ((i % self.width) as f64 - self.cx) * z / self.fx,
            ((i / self.width) as f64 - self.cy) * z / self.fy,
            z,
        ]
    }
    fn project(self, p: V, interior: bool) -> Option<usize> {
        if p[2] <= MIN_Z || !p.iter().all(|v| v.is_finite()) {
            return None;
        }
        let x = (self.fx * p[0] / p[2] + self.cx).round_ties_even();
        let y = (self.fy * p[1] / p[2] + self.cy).round_ties_even();
        let border = usize::from(interior);
        if x >= border as f64
            && x < (self.width - border) as f64
            && y >= border as f64
            && y < (self.height - border) as f64
        {
            Some(y as usize * self.width + x as usize)
        } else {
            None
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
pub struct Pose {
    pub rotation: M,
    pub translation: V,
}
impl Pose {
    pub fn identity() -> Self {
        Self {
            rotation: [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]],
            translation: [0.; 3],
        }
    }
    pub fn rotate(self, v: V) -> V {
        mv(self.rotation, v)
    }
    pub fn transform(self, v: V) -> V {
        add(self.rotate(v), self.translation)
    }
    pub fn compose(self, b: Self) -> Self {
        Self {
            rotation: mm(self.rotation, b.rotation),
            translation: self.transform(b.translation),
        }
    }
    pub fn inverse(self) -> Self {
        let rotation = transpose(self.rotation);
        Self {
            rotation,
            translation: mul(mv(rotation, self.translation), -1.),
        }
    }
    fn increment(self, d: [f64; 6]) -> Self {
        let w = [d[3], d[4], d[5]];
        let angle = norm(w);
        let k = [[0., -w[2], w[1]], [w[2], 0., -w[0]], [-w[1], w[0], 0.]];
        let k2 = mm(k, k);
        let (a, b) = if angle < 1e-12 {
            (1., 0.)
        } else {
            (angle.sin() / angle, (1. - angle.cos()) / (angle * angle))
        };
        let mut rotation = Self::identity().rotation;
        for i in 0..3 {
            for j in 0..3 {
                rotation[i][j] += a * k[i][j] + b * k2[i][j];
            }
        }
        Self {
            rotation,
            translation: [d[0], d[1], d[2]],
        }
        .compose(self)
    }
    fn angle(self) -> f64 {
        ((self.rotation[0][0] + self.rotation[1][1] + self.rotation[2][2] - 1.) / 2.)
            .clamp(-1., 1.)
            .acos()
    }
    fn finite_rigid(self) -> bool {
        let a = mm(transpose(self.rotation), self.rotation);
        self.translation.iter().all(|v| v.is_finite())
            && a.iter().enumerate().all(|(i, row)| {
                row.iter()
                    .enumerate()
                    .all(|(j, v)| v.is_finite() && (v - f64::from(i == j)).abs() < 1e-8)
            })
            && (dot(self.rotation[0], cross(self.rotation[1], self.rotation[2])) - 1.).abs() < 1e-8
    }
}
fn add(a: V, b: V) -> V {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
}
fn sub(a: V, b: V) -> V {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}
fn mul(a: V, b: f64) -> V {
    [a[0] * b, a[1] * b, a[2] * b]
}
fn dot(a: V, b: V) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}
fn norm(a: V) -> f64 {
    dot(a, a).sqrt()
}
fn cross(a: V, b: V) -> V {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}
fn transpose(a: M) -> M {
    std::array::from_fn(|i| std::array::from_fn(|j| a[j][i]))
}
fn mv(a: M, b: V) -> V {
    a.map(|row| dot(row, b))
}
fn mm(a: M, b: M) -> M {
    let bt = transpose(b);
    std::array::from_fn(|i| std::array::from_fn(|j| dot(a[i], bt[j])))
}

#[derive(Clone)]
struct Level {
    camera: Camera,
    vertices: Vec<V>,
    normals: Vec<V>,
}
fn pyramid(camera: Camera, raw: &[f64]) -> Vec<Level> {
    let mut depth = raw.to_vec();
    let mut levels = Vec::with_capacity(3);
    for s in [1, 2, 4] {
        let c = camera.scaled(s);
        if s != 1 {
            let old_width = c.width * 2;
            depth = (0..c.width * c.height)
                .map(|i| {
                    let k = i / c.width * 2 * old_width + i % c.width * 2;
                    let values = [
                        depth[k],
                        depth[k + 1],
                        depth[k + old_width],
                        depth[k + old_width + 1],
                    ];
                    let lo = values.iter().copied().fold(f64::INFINITY, f64::min);
                    let hi = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
                    if lo < MIN_Z || hi > MAX_Z || hi - lo > 0.05 + 0.01 * lo {
                        0.
                    } else {
                        values.iter().sum::<f64>() / 4.
                    }
                })
                .collect();
        }
        let vertices: Vec<V> = depth
            .iter()
            .enumerate()
            .map(|(i, &z)| c.point(i, z))
            .collect();
        let mut normals = vec![[0.; 3]; depth.len()];
        for y in 1..c.height - 1 {
            for x in 1..c.width - 1 {
                let i = y * c.width + x;
                let z = depth[i];
                if z <= MIN_Z || z >= MAX_Z {
                    continue;
                }
                let neighbours = [i + 1, i - 1, i + c.width, i - c.width];
                if neighbours
                    .iter()
                    .any(|&j| depth[j] <= MIN_Z || (depth[j] - z).abs() >= 0.05 + 0.01 * z)
                {
                    continue;
                }
                let normal = cross(
                    sub(vertices[i + 1], vertices[i - 1]),
                    sub(vertices[i + c.width], vertices[i - c.width]),
                );
                let size = norm(normal);
                if size > 1e-10 {
                    normals[i] = mul(normal, 1. / size);
                }
            }
        }
        levels.push(Level {
            camera: c,
            vertices,
            normals,
        });
    }
    levels.reverse();
    levels
}

#[derive(Clone, Debug, Serialize)]
pub struct Equation {
    pub count: usize,
    pub rms_m: f64,
    pub h: H,
    pub g: [f64; 6],
}
fn equation(target: &Level, source: &Level, pose: Pose, scale: usize) -> Equation {
    let mut e = Equation {
        count: 0,
        rms_m: 0.,
        h: [[0.; 6]; 6],
        g: [0.; 6],
    };
    let stride = if scale == 1 { 2 } else { 1 };
    let mut squared = 0.;
    for y in (0..source.camera.height).step_by(stride) {
        for x in (0..source.camera.width).step_by(stride) {
            let i = y * source.camera.width + x;
            if dot(source.normals[i], source.normals[i]) <= 0.25 {
                continue;
            }
            let q = pose.transform(source.vertices[i]);
            let Some(j) = target.camera.project(q, true) else {
                continue;
            };
            let n = target.normals[j];
            if dot(n, n) <= 0.25
                || norm(sub(q, target.vertices[j])) >= if scale == 4 { 0.12 } else { 0.08 }
                || dot(pose.rotate(source.normals[i]), n) <= 0.8
            {
                continue;
            }
            let r = dot(n, sub(q, target.vertices[j]));
            let rotation = cross(q, n);
            let jacobian = [n[0], n[1], n[2], rotation[0], rotation[1], rotation[2]];
            let weight = (0.01 / r.abs().max(1e-15)).min(1.);
            for a in 0..6 {
                e.g[a] += jacobian[a] * r * weight;
                for b in 0..6 {
                    e.h[a][b] += jacobian[a] * jacobian[b] * weight;
                }
            }
            squared += r * r;
            e.count += 1;
        }
    }
    e.rms_m = if e.count == 0 {
        0.
    } else {
        (squared / e.count as f64).sqrt()
    };
    e
}

#[derive(Clone, Debug, Serialize)]
pub struct Iteration {
    pub scale: usize,
    pub before: Pose,
    pub equation: Equation,
    pub scaled_condition: f64,
    pub delta: [f64; 6],
    pub after: Pose,
}
fn fit(
    target: &[Level],
    source: &[Level],
    initial: Pose,
    trace: &mut Vec<Iteration>,
) -> Result<(Pose, Equation), String> {
    let mut pose = initial;
    for ((t, s), (scale, cap)) in target.iter().zip(source).zip([(4, 10), (2, 7), (1, 5)]) {
        for _ in 0..cap {
            let e = equation(t, s, pose, scale);
            if e.count < MIN_SUPPORT {
                return Err("insufficient geometric support".into());
            }
            let (d, condition) = solve_normal(e.h, e.g, 1e6)?;
            if norm([d[0], d[1], d[2]]) > 0.1 || norm([d[3], d[4], d[5]]) > 0.15 {
                return Err("oversized geometric increment".into());
            }
            let next = pose.increment(d);
            if !next.finite_rigid() {
                return Err("nonrigid geometric result".into());
            }
            trace.push(Iteration {
                scale,
                before: pose,
                equation: e,
                scaled_condition: condition,
                delta: d,
                after: next,
            });
            pose = next;
            if norm([d[0], d[1], d[2]]) < 1e-5 && norm([d[3], d[4], d[5]]) < 1e-5 {
                break;
            }
        }
    }
    // Admission uses correspondences at the returned pose, not the previous iterate.
    let final_e = equation(&target[2], &source[2], pose, 1);
    if final_e.count < MIN_SUPPORT || final_e.rms_m > 0.03 || norm(pose.translation) > 0.5 {
        return Err("final geometric residual, support or displacement gate".into());
    }
    Ok((pose, final_e))
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct RasterStats {
    pub source_valid: usize,
    pub projected: usize,
    pub selected: usize,
}
fn raster(
    camera: Camera,
    depth: &[f64],
    weights: &[u8],
    pose: Pose,
) -> (Vec<f64>, Vec<u8>, RasterStats) {
    let mut output = vec![0.; depth.len()];
    let mut support = vec![0; depth.len()];
    let mut stats = RasterStats::default();
    for (i, &z) in depth.iter().enumerate() {
        if z <= MIN_Z || z >= MAX_Z {
            continue;
        }
        stats.source_valid += 1;
        let p = pose.transform(camera.point(i, z));
        if p[2] >= MAX_Z {
            continue;
        }
        let Some(j) = camera.project(p, false) else {
            continue;
        };
        stats.projected += 1;
        if output[j] == 0. || p[2] < output[j] {
            if output[j] == 0. {
                stats.selected += 1;
            }
            output[j] = p[2];
            support[j] = weights[i];
        }
        // Strictly smaller Z only: row-major traversal keeps the first exact tie.
    }
    (output, support, stats)
}
#[derive(Clone, Debug, Default, Serialize)]
pub struct FusionStats {
    pub warp: Option<RasterStats>,
    pub measurement: RasterStats,
    pub filled: usize,
    pub averaged: usize,
    pub replaced: usize,
    pub ignored: usize,
}
fn fuse(
    camera: Camera,
    model: &mut [f64],
    weights: &mut [u8],
    depth: &[f64],
    pose: Pose,
) -> FusionStats {
    let (new, present, measurement) = raster(camera, depth, &vec![1; depth.len()], pose);
    let mut stats = FusionStats {
        measurement,
        ..FusionStats::default()
    };
    for i in 0..model.len() {
        if present[i] == 0 {
            continue;
        }
        let old = model[i];
        if weights[i] == 0 {
            model[i] = new[i];
            weights[i] = 1;
            stats.filled += 1;
        } else if (new[i] - old).abs() < 0.03 + 0.01 * old {
            let w = f64::from(weights[i].min(16));
            model[i] = (w * old + new[i]) / (w + 1.);
            weights[i] = (weights[i] + 1).min(16);
            stats.averaged += 1;
        } else if new[i] < old - 0.03 - 0.01 * old {
            model[i] = new[i];
            weights[i] = 1;
            stats.replaced += 1;
        } else {
            stats.ignored += 1;
        }
    }
    stats
}

#[derive(Debug, Serialize)]
pub struct Update {
    pub timestamp: f64,
    pub accepted: bool,
    pub initialized: bool,
    pub lost: bool,
    pub rejection: Option<String>,
    pub first_from_current: Option<Pose>,
    pub last_accepted_timestamp: Option<f64>,
    pub keyframe_replaced: bool,
    pub iterations: Vec<Iteration>,
    pub final_equation: Option<Equation>,
    pub fusion: Option<FusionStats>,
}
struct Model {
    depth: Vec<f64>,
    weights: Vec<u8>,
    pyramid: Vec<Level>,
    key_root: Pose,
    initial: Pose,
}
pub struct Tracker {
    camera: Camera,
    model: Option<Model>,
    last_observed: Option<f64>,
    last_accepted: Option<f64>,
    lost: bool,
}
impl Tracker {
    pub fn new(camera: Camera) -> Result<Self, String> {
        camera.validate()?;
        Ok(Self {
            camera,
            model: None,
            last_observed: None,
            last_accepted: None,
            lost: false,
        })
    }
    /// Rejected fits do not mutate pose/model/accepted time. Valid acquisition
    /// clocks advance even for malformed depth, so expiry cannot be hidden.
    pub fn step(&mut self, timestamp: f64, depth: &[f64]) -> Update {
        let mut out = Update {
            timestamp,
            accepted: false,
            initialized: self.model.is_some(),
            lost: self.lost,
            rejection: None,
            first_from_current: None,
            last_accepted_timestamp: self.last_accepted,
            keyframe_replaced: false,
            iterations: Vec::new(),
            final_equation: None,
            fusion: None,
        };
        let result = (|| -> Result<(), String> {
            if !timestamp.is_finite()
                || !(0.0..=1e12).contains(&timestamp)
                || self.last_observed.is_some_and(|last| timestamp <= last)
            {
                return Err("invalid, duplicate or regressing acquisition clock".into());
            }
            self.last_observed = Some(timestamp);
            if self
                .last_accepted
                .is_some_and(|last| timestamp - last > AGE)
            {
                self.lost = true;
            }
            if self.lost {
                return Err("accepted-pose expiry latched; no reset".into());
            }
            if depth.len() != self.camera.width * self.camera.height
                || depth
                    .iter()
                    .any(|v| !v.is_finite() || !(0.0..=100.).contains(v))
            {
                return Err("invalid bounded depth image".into());
            }
            let current = pyramid(self.camera, depth);
            if self.model.is_none() {
                if current[0]
                    .normals
                    .iter()
                    .filter(|n| dot(**n, **n) > 0.25)
                    .count()
                    < MIN_SUPPORT
                {
                    return Err("insufficient initialization surface".into());
                }
                self.model = Some(Model {
                    depth: depth.to_vec(),
                    weights: depth.iter().map(|&z| u8::from(z > MIN_Z)).collect(),
                    pyramid: current,
                    key_root: Pose::identity(),
                    initial: Pose::identity(),
                });
                out.first_from_current = Some(Pose::identity());
                out.initialized = true;
            } else {
                let old = self.model.as_ref().expect("model checked");
                let (relative, final_e) =
                    fit(&old.pyramid, &current, old.initial, &mut out.iterations)?;
                let root = old.key_root.compose(relative);
                if !root.finite_rigid() {
                    return Err("nonrigid composed root".into());
                }
                let replace = norm(relative.translation) > 0.1 || relative.angle() > 0.1;
                let (mut map, mut weights, warp) = if replace {
                    let (d, w, stats) =
                        raster(self.camera, &old.depth, &old.weights, relative.inverse());
                    (d, w, Some(stats))
                } else {
                    (old.depth.clone(), old.weights.clone(), None)
                };
                let mut fusion = fuse(
                    self.camera,
                    &mut map,
                    &mut weights,
                    depth,
                    if replace { Pose::identity() } else { relative },
                );
                fusion.warp = warp;
                let next_pyramid = pyramid(self.camera, &map);
                self.model = Some(Model {
                    depth: map,
                    weights,
                    pyramid: next_pyramid,
                    key_root: if replace { root } else { old.key_root },
                    initial: if replace { Pose::identity() } else { relative },
                });
                out.first_from_current = Some(root);
                out.final_equation = Some(final_e);
                out.keyframe_replaced = replace;
                out.fusion = Some(fusion);
            }
            self.last_accepted = Some(timestamp);
            out.accepted = true;
            Ok(())
        })();
        out.rejection = result.err();
        out.lost = self.lost;
        out.last_accepted_timestamp = self.last_accepted;
        out
    }
}

// Scaled SPD solver and bounded Jacobi from this repository's reprojection implementation.
fn solve_normal(
    h: [[f64; 6]; 6],
    g: [f64; 6],
    max_condition: f64,
) -> Result<([f64; 6], f64), String> {
    let mut scale = [0.0; 6];
    let mut a = [[0.0; 6]; 6];
    for i in 0..6 {
        if !h[i][i].is_finite() || h[i][i] <= 0.0 || !g[i].is_finite() {
            return Err("ill-conditioned projective depth normal matrix".into());
        }
        scale[i] = h[i][i].sqrt();
    }
    for i in 0..6 {
        for j in 0..6 {
            a[i][j] = h[i][j] / (scale[i] * scale[j]);
            if !a[i][j].is_finite() {
                return Err("nonfinite projective depth normal matrix".into());
            }
        }
    }
    let eigen = eigenvalues(a);
    let smallest = eigen.iter().copied().fold(f64::INFINITY, f64::min);
    let largest = eigen.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let condition = largest / smallest;
    if smallest <= 0.0 || !condition.is_finite() || condition > max_condition {
        return Err("ill-conditioned projective depth normal matrix".into());
    }
    let mut l = [[0.0; 6]; 6];
    for i in 0..6 {
        for j in 0..=i {
            let mut value = a[i][j];
            for k in 0..j {
                value -= l[i][k] * l[j][k];
            }
            if i == j {
                if value <= 0.0 || !value.is_finite() {
                    return Err("singular projective depth normal solve".into());
                }
                l[i][j] = value.sqrt();
            } else {
                l[i][j] = value / l[j][j];
            }
        }
    }
    let mut y = [0.0; 6];
    for i in 0..6 {
        let mut value = -g[i] / scale[i];
        for (j, previous) in y.iter().enumerate().take(i) {
            value -= l[i][j] * previous;
        }
        y[i] = value / l[i][i];
    }
    let mut d = [0.0; 6];
    for i in (0..6).rev() {
        let mut value = y[i];
        for j in i + 1..6 {
            value -= l[j][i] * d[j];
        }
        d[i] = value / l[i][i];
    }
    for i in 0..6 {
        d[i] /= scale[i];
        if !d[i].is_finite() {
            return Err("nonfinite projective depth increment".into());
        }
    }
    Ok((d, condition))
}
/// Maximum-pivot symmetric Jacobi, bounded to 256 rotations on a 6x6 matrix.
fn eigenvalues(mut a: [[f64; 6]; 6]) -> [f64; 6] {
    for _ in 0..256 {
        let (mut p, mut q) = (0, 1);
        let mut maximum = a[p][q].abs();
        for (i, row) in a.iter().enumerate() {
            for (j, value) in row.iter().enumerate().skip(i + 1) {
                if value.abs() > maximum {
                    maximum = value.abs();
                    p = i;
                    q = j;
                }
            }
        }
        if maximum <= 1e-14 {
            break;
        }
        let angle = 0.5 * (2.0 * a[p][q]).atan2(a[q][q] - a[p][p]);
        let (s, c) = angle.sin_cos();
        let app = a[p][p];
        let aqq = a[q][q];
        let apq = a[p][q];
        for k in 0..6 {
            if k != p && k != q {
                let akp = a[k][p];
                let akq = a[k][q];
                a[k][p] = c * akp - s * akq;
                a[p][k] = a[k][p];
                a[k][q] = s * akp + c * akq;
                a[q][k] = a[k][q];
            }
        }
        a[p][p] = c * c * app - 2.0 * s * c * apq + s * s * aqq;
        a[q][q] = s * s * app + 2.0 * s * c * apq + c * c * aqq;
        a[p][q] = 0.0;
        a[q][p] = 0.0;
    }
    std::array::from_fn(|i| a[i][i])
}

#[cfg(test)]
mod tests {
    use super::*;
    fn camera() -> Camera {
        Camera {
            width: 128,
            height: 96,
            fx: 110.,
            fy: 110.,
            cx: 63.5,
            cy: 47.5,
        }
    }
    fn surface() -> Vec<f64> {
        (0..128 * 96)
            .map(|i| {
                1.5 + 0.12 * ((i % 128) as f64 / 9.).sin() + 0.08 * ((i / 128) as f64 / 11.).cos()
            })
            .collect()
    }
    #[test]
    fn duplicate_and_bad_depth_do_not_refresh_and_expiry_latches() {
        let mut tracker = Tracker::new(camera()).unwrap();
        let depth = surface();
        assert!(tracker.step(1., &depth).accepted);
        assert!(!tracker.step(1., &depth).accepted);
        let rejected = tracker.step(1.1, &[]);
        assert!(!rejected.accepted && !rejected.lost);
        assert_eq!(rejected.last_accepted_timestamp, Some(1.));
        let expired = tracker.step(1.201, &[]);
        assert!(expired.lost && !expired.accepted);
        assert!(!tracker.step(1.21, &depth).accepted);
        assert_eq!(tracker.last_accepted, Some(1.));
    }
    #[test]
    fn geometric_rejection_does_not_modify_model_or_accepted_pose() {
        let mut tracker = Tracker::new(camera()).unwrap();
        assert!(tracker.step(1., &surface()).accepted);
        let before = tracker.model.as_ref().unwrap().depth.clone();
        let rejected = tracker.step(1.03, &vec![0.; 128 * 96]);
        assert!(!rejected.accepted && rejected.first_from_current.is_none());
        assert_eq!(tracker.model.as_ref().unwrap().depth, before);
        assert_eq!(tracker.last_accepted, Some(1.));
        assert!(tracker.step(1.06, &surface()).accepted);
    }
    #[test]
    fn a_single_plane_is_rejected_as_unobservable() {
        let c = camera();
        let depth = vec![2.; c.width * c.height];
        let mut tracker = Tracker::new(c).unwrap();
        assert!(tracker.step(1., &depth).accepted);
        let result = tracker.step(1.03, &depth);
        assert!(!result.accepted);
        assert!(result.rejection.unwrap().contains("condition"));
    }
    #[test]
    fn malformed_initial_frame_does_not_establish_a_pose() {
        let mut tracker = Tracker::new(camera()).unwrap();
        for depth in [
            vec![0.; 128 * 96],
            vec![f64::NAN; 128 * 96],
            vec![-1.; 128 * 96],
            vec![1.; 20],
        ] {
            assert!(
                !tracker
                    .step(tracker.last_observed.unwrap_or(0.) + 0.01, &depth)
                    .accepted
            );
            assert!(tracker.model.is_none() && tracker.last_accepted.is_none());
        }
        assert!(tracker.step(1., &surface()).accepted);
    }
    #[test]
    fn raster_has_hand_calculated_nearest_depth_and_index_ties() {
        let c = Camera {
            width: 32,
            height: 32,
            fx: 32.,
            fy: 32.,
            cx: 15.5,
            cy: 15.5,
        };
        let mut depth = vec![0.; 1024];
        let mut weights = vec![0; 1024];
        depth[16 * 32 + 16] = 1.;
        weights[16 * 32 + 16] = 2;
        depth[16 * 32 + 17] = 1.;
        weights[16 * 32 + 17] = 7;
        let pose = Pose {
            translation: [0., 0., 1.],
            ..Pose::identity()
        };
        let (z, w, stats) = raster(c, &depth, &weights, pose);
        assert_eq!(
            (stats.source_valid, stats.projected, stats.selected),
            (2, 2, 1)
        );
        assert_eq!((z[16 * 32 + 16], w[16 * 32 + 16]), (2., 2));
        depth[17 * 32 + 16] = 0.5;
        weights[17 * 32 + 16] = 4;
        let (z, w, stats) = raster(c, &depth, &weights, pose);
        assert_eq!((stats.projected, stats.selected), (3, 1));
        assert_eq!((z[16 * 32 + 16], w[16 * 32 + 16]), (1.5, 4));
    }
    #[test]
    fn depth_fusion_weight_cap_keeps_updating_without_unbounded_weight() {
        let c = camera();
        let mut model = vec![2.; 128 * 96];
        let mut weights = vec![16; 128 * 96];
        let stats = fuse(
            c,
            &mut model,
            &mut weights,
            &vec![2.01; 128 * 96],
            Pose::identity(),
        );
        assert_eq!(stats.averaged, 128 * 96);
        assert!(weights.iter().all(|&w| w == 16));
        assert!((model[123] - (16. * 2. + 2.01) / 17.).abs() < 1e-15);
    }
}
