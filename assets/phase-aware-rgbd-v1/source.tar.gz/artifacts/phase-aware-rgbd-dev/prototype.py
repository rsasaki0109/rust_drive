"""Viewed phase-gated intensity + fused-depth algorithm experiment."""
import hashlib,importlib.util,io,json,sys
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path('/workspace/rust_drive');BASE=ROOT/'artifacts/phase-aware-rgbd-dev'
spec=importlib.util.spec_from_file_location('geometry',BASE/'geometry-base.py');geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
def sha(body):return hashlib.sha256(body).hexdigest()
def write(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def images(gray):
 layers={1:gray}
 for s in [2,4]:
  a=layers[s//2];layers[s]=(a[::2,::2]+a[::2,1::2]+a[1::2,::2]+a[1::2,1::2])/4
 return layers
def sample(image,x,y):
 x0=np.floor(x).astype(int);y0=np.floor(y).astype(int);dx=x-x0;dy=y-y0
 a,b,c,d=image[y0,x0],image[y0,x0+1],image[y0+1,x0],image[y0+1,x0+1]
 value=(1-dx)*(1-dy)*a+dx*(1-dy)*b+(1-dx)*dy*c+dx*dy*d
 gx=(1-dy)*(b-a)+dy*(d-c);gy=(1-dx)*(c-a)+dx*(d-b)
 return value,gx,gy
# Hand witness for the exact derivative used by the new term.
y,x=np.mgrid[:8,:8];value,gx,gy=sample(3*x+5*y+7,np.array([2.25]),np.array([3.5]));np.testing.assert_allclose([value[0],gx[0],gy[0]],[31.25,3.,5.],atol=1e-12,rtol=0)
def fit(target,source,initial,target_i,source_i,photo_enabled):
 T=initial.copy();trace=[]
 for s,cap in [(4,10),(2,7),(1,5)]:
  v,n,f,cx,cy=target[s];src,sn,*_=source[s];h,w=v.shape[:2];stride=2 if s==1 else 1
  src=src[::stride,::stride].reshape(-1,3);sn=sn[::stride,::stride].reshape(-1,3);ci=source_i[s][::stride,::stride].ravel();ok=np.linalg.norm(sn,axis=1)>.5;src,sn,ci=src[ok],sn[ok],ci[ok]
  for it in range(cap):
   q=src@T[:3,:3].T+T[:3,3];qn=sn@T[:3,:3].T;z=q[:,2];uf=f*q[:,0]/z+cx;vf=f*q[:,1]/z+cy;u=np.rint(uf).astype(int);vv=np.rint(vf).astype(int)
   inside=(z>.3)&(u>=1)&(u<w-1)&(vv>=1)&(vv<h-1);ids=np.flatnonzero(inside);u=u[inside];vv=vv[inside];p=v[vv,u];normal=n[vv,u]
   valid=(np.linalg.norm(normal,axis=1)>.5)&(np.linalg.norm(q[ids]-p,axis=1)<(.12 if s==4 else .08))&(np.sum(qn[ids]*normal,axis=1)>.8);ids=ids[valid];p=p[valid];normal=normal[valid];query=q[ids]
   if len(ids)<200:raise ValueError('geometric support')
   r=np.sum(normal*(query-p),axis=1);J=np.column_stack([normal,np.cross(query,normal)]);weight=np.minimum(1.,.01/np.maximum(abs(r),1e-15));H=J.T@(weight[:,None]*J)/.005**2;g=J.T@(weight*r)/.005**2
   photo_count=0;photo_rms=None
   if photo_enabled:
    intensity,gx,gy=sample(target_i[s],uf[ids],vf[ids]);photo=intensity-ci[ids];ok=(abs(photo)<30)&(np.hypot(gx,gy)>=1.);photo_count=int(ok.sum())
    if photo_count>=200:
     qq=query[ok];zz=qq[:,2];ix,iy=gx[ok],gy[ok];gradient=np.column_stack([ix*f/zz,iy*f/zz,-f*(ix*qq[:,0]+iy*qq[:,1])/(zz*zz)]);JP=np.column_stack([gradient,np.cross(qq,gradient)]);pr=photo[ok];wp=(1-(pr/30)**2)**2
     H+=JP.T@(wp[:,None]*JP)/100.;g+=JP.T@(wp*pr)/100.;photo_rms=float(np.sqrt(np.mean(pr*pr)))
   scale=np.sqrt(np.diag(H));A=H/scale[:,None]/scale[None,:];eigen=np.linalg.eigvalsh(A)
   if eigen[0]<=0 or eigen[-1]/eigen[0]>1e6:raise ValueError('condition')
   delta=np.linalg.solve(A,-g/scale)/scale
   if np.linalg.norm(delta[:3])>.1 or np.linalg.norm(delta[3:])>.15:raise ValueError('increment')
   E=geo.exp(delta[3:]);T[:3,3]=E@T[:3,3]+delta[:3];T[:3,:3]=E@T[:3,:3];trace.append(dict(scale=s,geometric_support=len(ids),geometric_rms_m=float(np.sqrt(np.mean(r*r))),photo_support=photo_count,photo_rms=photo_rms,condition=float(eigen[-1]/eigen[0])))
   if np.linalg.norm(delta[:3])<1e-5 and np.linalg.norm(delta[3:])<1e-5:break
 # Re-evaluate the geometric admission at the returned pose.
 v,n,f,cx,cy=target[1];src,sn,*_=source[1];src,sn=src[::2,::2].reshape(-1,3),sn[::2,::2].reshape(-1,3);ok=np.linalg.norm(sn,axis=1)>.5;src,sn=src[ok],sn[ok];q=src@T[:3,:3].T+T[:3,3];qn=sn@T[:3,:3].T;z=q[:,2];u=np.rint(f*q[:,0]/z+cx).astype(int);vv=np.rint(f*q[:,1]/z+cy).astype(int);valid=(z>.3)&(u>=1)&(u<639)&(vv>=1)&(vv<479);ids=np.flatnonzero(valid);p=v[vv[valid],u[valid]];normal=n[vv[valid],u[valid]];valid=(np.linalg.norm(normal,axis=1)>.5)&(np.linalg.norm(q[ids]-p,axis=1)<.08)&(np.sum(qn[ids]*normal,axis=1)>.8);r=np.sum(normal[valid]*(q[ids[valid]]-p[valid]),axis=1)
 if len(r)<200 or np.sqrt(np.mean(r*r))>.03 or np.linalg.norm(T[:3,3])>.5:raise ValueError('final residual/support/jump')
 return T,trace

def operational(case,out):
 base=ROOT/'data'/case;manifest_body=(base/'manifest.json').read_bytes();m=json.loads(manifest_body);frames=m['frames'];inventory={v['file']:v for v in m['files']}
 def verified(name):
  body=(base/'raw'/name).read_bytes();pin=inventory[name];assert len(body)==pin['bytes'] and sha(body)==pin['sha256'];return body
 for name in inventory:verified(name)
 assert len(frames)==180 and all(b['depth_timestamp']>a['depth_timestamp'] and b['rgb_timestamp']>=a['rgb_timestamp'] for a,b in zip(frames,frames[1:]));assert all(abs(f['rgb_timestamp']-f['depth_timestamp'])<=.02 for f in frames)
 write(out/'freeze.json',dict(manifest_sha256=sha(manifest_body),prototype_sha256=sha(Path(__file__).read_bytes()),geometry_base_sha256=sha((BASE/'geometry-base.py').read_bytes()),design_sha256=sha((ROOT/'assets/phase-aware-rgbd-v1/design.json').read_bytes()),sources={n:v['sha256'] for n,v in inventory.items()},data_role='viewed development',ground_truth_operational=False))
 def load(frame):
  d=np.asarray(Image.open(io.BytesIO(verified(frame['depth_file']))),dtype=float)/5000.;color=np.asarray(Image.open(io.BytesIO(verified(frame['rgb_file']))),dtype=np.uint32);assert d.shape==(480,640) and color.shape==(480,640,3);gray=((77*color[:,:,0]+150*color[:,:,1]+29*color[:,:,2])>>8).astype(float);return d,images(gray)
 first=frames[0];model,key_i=load(first);weights=(model>.3).astype(float);target=geo.pyramid(model);keyroot=np.eye(4);initial=np.eye(4);last=first['depth_timestamp'];observed_rgb=first['rgb_timestamp'];key_phase=first['rgb_timestamp']-last;lost=False;rows=[]
 for frame in frames[1:]:
  stamp=frame['depth_timestamp'];phase=frame['rgb_timestamp']-stamp;photo_enabled=frame['rgb_timestamp']>observed_rgb and abs(phase-key_phase)<=.005;observed_rgb=frame['rgb_timestamp'];row=dict(source_index=frame['source_index'],depth_timestamp=stamp,accepted=False,photo_enabled=photo_enabled,phase_disagreement_s=phase-key_phase)
  if stamp-last>.2:lost=True
  try:
   if lost:raise ValueError('accepted-pose expiry latched')
   raw,current_i=load(frame);relative,trace=fit(target,geo.pyramid(raw),initial,key_i,current_i,photo_enabled);root=keyroot@relative;angle=np.arccos(np.clip((np.trace(relative[:3,:3])-1)/2,-1,1));replace=np.linalg.norm(relative[:3,3])>.1 or angle>.1
   if replace:
    model,weights=geo.raster(model,np.linalg.inv(relative),weights);keyroot=root.copy();initial=np.eye(4);key_i=current_i;key_phase=phase;model,weights=geo.fuse(model,weights,raw,np.eye(4))
   else:initial=relative;model,weights=geo.fuse(model,weights,raw,relative)
   target=geo.pyramid(model);last=stamp;row.update(accepted=True,first_from_current=root.tolist(),trace=trace,keyframe_replaced=bool(replace))
  except ValueError as error:row['rejection']=str(error)
  rows.append(row)
  if len(rows)%30==0:print(case,'processed',len(rows),flush=True)
 write(out/'sensor-only.json',dict(frames=rows,lost=lost,ground_truth_parsed=False));return frames,rows,lost,verified

def main():
 output=BASE/'first';output.mkdir();saved={}
 for case in ['tum-fr1-room-temporal','tum-fr1-desk2-independent']:
  folder=output/case;folder.mkdir();saved[case]=operational(case,folder)
 # No numeric labels until both operational trajectories are complete.
 spec=importlib.util.spec_from_file_location('reference',ROOT/'scripts/check-opencv-rgbd.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref);ref.controls()
 summaries={}
 for case,(frames,rows,lost,verified) in saved.items():
  labels=np.loadtxt(io.BytesIO(verified('groundtruth.txt')),comments='#');assert labels.ndim==2 and labels.shape[1]==8 and np.isfinite(labels).all() and np.all(np.diff(labels[:,0])>0);origin=np.linalg.inv(ref.truth_at(labels,frames[0]['depth_timestamp']));errors=[]
  for row in rows:
   if not row['accepted']:continue
   estimate=np.array(row['first_from_current']);truth=origin@ref.truth_at(labels,row['depth_timestamp']);p=float(np.linalg.norm(estimate[:3,3]-truth[:3,3]));a=float(np.arccos(np.clip((np.trace(truth[:3,:3].T@estimate[:3,:3])-1)/2,-1,1)));row.update(position_error_m=p,rotation_error_rad=a,accurate=p<=.1 and a<=.1);errors.append((p,a))
  summary=dict(total_updates=179,accepted=len(errors),root_accurate=sum(r.get('accurate',False) for r in rows),lost=lost,max_position_error_m=max(v[0] for v in errors),max_rotation_error_rad=max(v[1] for v in errors),photo_enabled_updates=sum(r['photo_enabled'] for r in rows));summaries[case]=summary;write(output/case/'results.json',dict(summary=summary,frames=rows));print(case,json.dumps(summary),flush=True)
 write(output/'summary.json',summaries)
if __name__=='__main__':main()
