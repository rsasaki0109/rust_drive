import json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image

def skew(v):
 x,y,z=v;return np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
def exp(v):
 a=np.linalg.norm(v);K=skew(v)
 return np.eye(3)+K if a<1e-12 else np.eye(3)+np.sin(a)/a*K+(1-np.cos(a))/(a*a)*(K@K)
def pyramid(raw):
 d=np.asarray(raw,dtype=float);layers={1:d}
 for s in [2,4]:
  a=layers[s//2];b=np.stack([a[dy::2,dx::2] for dy,dx in [(0,0),(0,1),(1,0),(1,1)]])
  low=b.min(axis=0);high=b.max(axis=0);v=b.mean(axis=0);v[(low<.3)|(high>5)|(high-low>.05+.01*low)]=0;layers[s]=v
 result={}
 for s in [4,2,1]:
  d=layers[s];h,w=d.shape;y,x=np.mgrid[:h,:w];f=525/s;cx=320/s-.5;cy=240/s-.5
  v=np.stack([(x-cx)*d/f,(y-cy)*d/f,d],axis=-1);n=np.zeros_like(v)
  a=v[1:-1,2:]-v[1:-1,:-2];b=v[2:,1:-1]-v[:-2,1:-1];cross=np.cross(a,b);norm=np.linalg.norm(cross,axis=-1)
  ok=(norm>1e-10)&(d[1:-1,1:-1]>.3)&(d[1:-1,1:-1]<5)
  for side in [d[1:-1,2:],d[1:-1,:-2],d[2:,1:-1],d[:-2,1:-1]]:ok&=(side>.3)&(abs(side-d[1:-1,1:-1])<.05+.01*d[1:-1,1:-1])
  n[1:-1,1:-1][ok]=cross[ok]/norm[ok,None]
  result[s]=(v,n,f,cx,cy)
 return result
def fit(previous,current,initial):
 T=initial.copy();detail=[]
 for s,iterations in [(4,10),(2,7),(1,5)]:
  v,n,f,cx,cy=previous[s];src,sn,*_=current[s];h,w=v.shape[:2]
  step=2 if s==1 else 1
  src=src[::step,::step].reshape(-1,3);sn=sn[::step,::step].reshape(-1,3);ok=np.linalg.norm(sn,axis=1)>.5;src=src[ok];sn=sn[ok]
  for it in range(iterations):
   p=src@T[:3,:3].T+T[:3,3];pn=sn@T[:3,:3].T
   zz=p[:,2];u=np.rint(f*p[:,0]/zz+cx).astype(int);vv=np.rint(f*p[:,1]/zz+cy).astype(int)
   mask=(zz>.3)&(u>=1)&(u<w-1)&(vv>=1)&(vv<h-1);ids=np.flatnonzero(mask);u=u[mask];vv=vv[mask]
   target=v[vv,u];normal=n[vv,u];dist=np.linalg.norm(p[ids]-target,axis=1)
   valid=(np.linalg.norm(normal,axis=1)>.5)&(dist<.12 if s==4 else dist<.08)&(np.sum(pn[ids]*normal,axis=1)>.8)
   ids=ids[valid];target=target[valid];normal=normal[valid];query=p[ids]
   if len(ids)<200:raise ValueError('support '+str(len(ids)))
   r=np.sum(normal*(query-target),axis=1);J=np.column_stack([normal,np.cross(query,normal)]);weight=np.minimum(1.,.01/np.maximum(abs(r),1e-15))
   H=J.T@(J*weight[:,None]);g=J.T@(r*weight);scale=np.sqrt(np.diag(H));A=H/scale[:,None]/scale[None,:];eig=np.linalg.eigvalsh(A)
   if eig[0]<eig[-1]/1e6:raise ValueError('condition')
   d=np.linalg.solve(A,-g/scale)/scale
   if np.linalg.norm(d[:3])>.1 or np.linalg.norm(d[3:])>.15:raise ValueError('step')
   E=exp(d[3:]);T[:3,3]=E@T[:3,3]+d[:3];T[:3,:3]=E@T[:3,:3]
   if np.linalg.norm(d[:3])<1e-5 and np.linalg.norm(d[3:])<1e-5:break
  detail.append([s,len(ids),float(np.sqrt(np.mean(r*r))),float(eig[-1]/eig[0])])
 if detail[-1][2]>.03 or np.linalg.norm(T[:3,3])>.5:raise ValueError('residual or jump')
 return T,detail
def raster(depth,T,weights):
 h,w=depth.shape;y,x=np.mgrid[:h,:w];v=np.stack([(x-319.5)*depth/525.,(y-239.5)*depth/525.,depth],axis=-1).reshape(-1,3);keep=(v[:,2]>.3)&(v[:,2]<5);v=v[keep];sw=weights.ravel()[keep];p=v@T[:3,:3].T+T[:3,3];z=p[:,2]
 u=np.rint(525*p[:,0]/z+319.5).astype(int);vv=np.rint(525*p[:,1]/z+239.5).astype(int);ok=(z>.3)&(z<5)&(u>=0)&(u<w)&(vv>=0)&(vv<h);u=u[ok];vv=vv[ok];z=z[ok];sw=sw[ok];idx=vv*w+u;order=np.lexsort((np.arange(len(idx)),z,idx));idx=idx[order];first=np.r_[True,idx[1:]!=idx[:-1]];sel=order[first];out=np.zeros(h*w);weight=np.zeros(h*w);out[idx[first]]=z[sel];weight[idx[first]]=sw[sel];return out.reshape(h,w),weight.reshape(h,w)
def fuse(model,weights,depth,T):
 new,nw=raster(depth,T,np.ones_like(depth));valid=nw>0;empty=(weights==0)&valid;close=(weights>0)&valid&(abs(new-model)<.03+.01*model);near=valid&(weights>0)&(new<model-.03-.01*model)
 old=np.minimum(16.,weights);model[close]=(old[close]*model[close]+new[close])/(old[close]+1);weights[close]=np.minimum(16.,weights[close]+1);model[empty|near]=new[empty|near];weights[empty|near]=1
 return model,weights

