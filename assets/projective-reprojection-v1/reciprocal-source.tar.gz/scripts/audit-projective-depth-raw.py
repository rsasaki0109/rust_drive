#!/usr/bin/env python3
"""Reconstruct raw depth, all ICP equations and fused models without decoding pose truth."""
import argparse
import copy
import gzip
import importlib.util
import io
import json
from pathlib import Path

import numpy as np
from PIL import Image
from projective_depth_common import CAMERA, ROOT, audit_iterations, audit_sequence, fresh, require, sha, write
from projective_depth_raw import compare_equation, fuse, normal_equation, pyramid, raster, reconstruct_update


def read(path, limit=8*1024*1024):
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,'bounded regular input')
    return path.read_bytes()


def document(path):
    body = read(path,64*1024*1024 if path.suffix=='.json' else 8*1024*1024)
    if path.suffix == '.gz':
        with gzip.GzipFile(fileobj=io.BytesIO(body)) as stream:
            body = stream.read(64*1024*1024+1)
        require(len(body) <= 64*1024*1024,'bounded expanded report')
    def invalid(value):
        raise ValueError('nonfinite JSON: '+value)
    return json.loads(body,parse_constant=invalid)


def verify_prior(path):
    packet = ROOT/'assets/projective-depth-rust-v1'
    pin = document(packet/'files.json')[str(path.relative_to(packet))]
    body = read(path)
    require(len(body) == pin['bytes'] and sha(body) == pin['sha256'],'immutable prior evidence binding')


def hand_controls():
    c = dict(width=8,height=8,fx=2.,fy=4.,cx=0.,cy=0.)
    layer = pyramid(np.full((8,8),4.),c)
    np.testing.assert_allclose(layer[1]['vertices'][2,1],[2.,2.,4.],atol=0,rtol=0)
    np.testing.assert_allclose(layer[1]['normals'][2,1],[0.,0.,1.],atol=0,rtol=0)
    require(layer[2]['camera']['cx'] == -.25 and layer[2]['camera']['cy'] == -.25,
            'half-pixel pyramid center convention')
    raw = np.ones((8,8))
    raw[0,0] = 0.
    raw[0,2] = 1.2
    raw[0:2,4:6] = [[1.,1.02],[1.,1.02]]
    reduced = pyramid(raw,c)[2]['depth']
    np.testing.assert_allclose(reduced[0,:3],[0.,0.,1.01],atol=1e-15,rtol=0)
    c = dict(width=32,height=32,fx=32.,fy=32.,cx=15.5,cy=15.5)
    raw = np.zeros((32,32));weight = np.zeros((32,32),dtype=np.uint8)
    raw[16,16:18] = 1.
    weight[16,16:18] = [2,7]
    transform = np.eye(4);transform[2,3] = 1.
    output,w,stats = raster(raw,weight,transform,c)
    require(stats == dict(source_valid=2,projected=2,selected=1)
            and output[16,16] == 2. and w[16,16] == 2,'exact index tie witness')
    raw[17,16],weight[17,16] = .5,4
    output,w,stats = raster(raw,weight,transform,c)
    require(stats == dict(source_valid=3,projected=3,selected=1)
            and output[16,16] == 1.5 and w[16,16] == 4,'nearer Z wins independent of index')
    model = np.full((32,32),2.);weight = np.ones((32,32),dtype=np.uint8)
    raw = np.zeros((32,32));raw[0,:4] = [2.01,1.,3.,1.5]
    model[0,3],weight[0,3] = 0.,0
    output,w,stats = fuse(model,weight,raw,np.eye(4),c)
    np.testing.assert_allclose(output[0,:4],[2.005,1.,2.,1.5],atol=1e-15,rtol=0)
    require([stats[k] for k in ('filled','averaged','replaced','ignored')] == [1,1,1,1],
            'four hand-calculated fusion partitions')
    model[:],weight[:],raw[:] = 2.,16,2.01
    output,w,_ = fuse(model,weight,raw,np.eye(4),c)
    np.testing.assert_allclose(output,(16*2.+2.01)/17,atol=1e-15,rtol=0)
    require(np.all(w == 16),'fusion weight cap still updates depth')
    layer = pyramid(np.ones((32,32)),c)[1]
    transform = np.eye(4);transform[2,3] = .01
    e = normal_equation(layer,layer,transform,1)
    require(e['count'] == 225,'hand-calculated planar sample count')
    np.testing.assert_allclose([e['h'][2,2],e['g'][2],e['rms_m']],[225.,2.25,.01],atol=1e-10,rtol=0)
    return dict(metre_axis_normal_witness=True,half_pixel_centers=True,invalid_discontinuous_reduction=True,
                exact_raster_tie_and_occlusion=True,four_fusion_partitions=True,
                capped_weight_arithmetic=True,hand_calculated_225_point_plane_equation=True)


def analytic(output, reports, reprojection='point', correspondence='forward'):
    spec = importlib.util.spec_from_file_location('independent_scene',ROOT/'scripts/check-projective-depth.py')
    scene = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scene)
    first = scene.render(np.eye(4))
    summaries = []
    witnesses = []
    for index in range(1,5):
        path = reports/('motion-'+str(index)+'.json') if reports else \
            ROOT/'assets/projective-depth-rust-v1'/('motion-'+str(index)+'.json.gz')
        if reports is None:
            verify_prior(path)
        record = document(path)
        raw = scene.render(np.asarray(record['expected']))
        update = record['result']
        audit_iterations(update)
        _,_,checked = reconstruct_update(first,(first > .3).astype(np.uint8),raw,scene.CAMERA,update,reprojection,correspondence)
        summaries.append(dict(motion=index,report_sha256=sha(read(path)),**checked))
        witnesses.append((first,raw,scene.CAMERA,update))
    model,raw,c,original = witnesses[2]
    rejected = []
    def corruption(name, change):
        altered = copy.deepcopy(original)
        change(altered)
        try:
            reconstruct_update(model,(model > .3).astype(np.uint8),raw,c,altered,reprojection,correspondence)
        except (AssertionError,ValueError,KeyError,TypeError,IndexError):
            rejected.append(name)
        else:
            raise ValueError('undetected raw audit corruption: '+name)
    def rescale_normal(u):
        e = u['iterations'][0]['equation']
        e['h'] = (2*np.asarray(e['h'])).tolist()
        e['g'] = (2*np.asarray(e['g'])).tolist()
    rescaled = copy.deepcopy(original)
    rescale_normal(rescaled)
    audit_iterations(rescaled)  # A valid solve alone cannot detect joint H/g scaling.
    corruption('joint H/g rescaling with unchanged valid solve',rescale_normal)
    corruption('false correspondence count',lambda u:u['iterations'][0]['equation'].update(
        count=u['iterations'][0]['equation']['count']+1))
    corruption('false per-iteration RMS',lambda u:u['iterations'][0]['equation'].update(
        rms_m=u['iterations'][0]['equation']['rms_m']+.001))
    corruption('false final support',lambda u:u['final_equation'].update(count=u['final_equation']['count']+1))
    corruption('false returned-pose RMS',lambda u:u['final_equation'].update(rms_m=.02))
    def move_fusion(u):
        require(u['fusion']['averaged'] > 0,'nonempty analytic fusion witness')
        u['fusion']['averaged'] -= 1
        u['fusion']['ignored'] += 1
    corruption('fusion category moved while total remains valid',move_fusion)
    write(output/'analytic-audit.json',dict(hand_controls=hand_controls(),motions=summaries,
        rejected_corruptions=rejected,prior_solve_only_auditor_accepts_rescaled_Hg=True))


def recorded(case, output, reports=None):
    source = ROOT/'data'/case
    prior = reports/case if reports else ROOT/'assets/projective-depth-rust-v1'/case
    freeze_path = prior/'freeze.json' if reports else prior/'final-freeze.json'
    if reports is None:verify_prior(freeze_path)
    freeze = document(freeze_path)
    reprojection = freeze.get('reprojection','point')
    correspondence = freeze.get('correspondence','forward')
    require(correspondence in ('forward','reciprocal'),'declared correspondence policy')
    require(reprojection in ('point','tangent_plane'),'declared reprojection policy')
    ledger_path = prior/'sensor-only.json' if reports else prior/'sensor-only.json.gz'
    if reports is None:verify_prior(ledger_path)
    ledger = document(ledger_path)
    require(ledger['ground_truth_parsed'] is False,'original pre-label operational ledger')
    manifest_body = read(source/'manifest.json')
    require(sha(manifest_body) == freeze['manifest_sha256'],'frozen manifest binding')
    manifest = json.loads(manifest_body)
    frames = manifest['frames']
    outcomes = ledger['frames']
    require(len(frames) == len(outcomes) == 180 and freeze['camera'] == CAMERA,'complete fixed selection and camera')
    require([f['source_index'] for f in frames] == list(range(100,280)),'unchanged acquisition indices')
    def verified(frame):
        name = frame['depth_file']
        require(Path(name).name == name,'plain source filename')
        body = read(source/'raw'/name,4*1024*1024)
        pin = freeze['inputs'][name]
        require(len(body) == pin['bytes'] and sha(body) == pin['sha256'],'raw depth source binding')
        return body
    for frame in frames:
        verified(frame)  # Hashes only; no pixel or reference label decoding yet.
    sources = [Path(__file__),ROOT/'scripts/projective_depth_raw.py',ROOT/'scripts/projective_depth_common.py',
               ROOT/'scripts/check-projective-depth.py',ROOT/'scripts/requirements-visual.txt',
               ROOT/'assets/projective-depth-raw-audit-v1/design.json']
    write(output/'freeze.json',dict(dataset=case,source_sha256={str(p.relative_to(ROOT)):sha(read(p)) for p in sources},
        manifest_sha256=sha(manifest_body),original_freeze_sha256=sha(read(freeze_path)),reprojection=reprojection,correspondence=correspondence,
        original_sensor_ledger_sha256=sha(read(ledger_path,64*1024*1024)),depth_source_count=180,
        ground_truth_decoded=False,raw_color_decoded=False))
    steps = audit_sequence(outcomes,[f['depth_timestamp'] for f in frames])
    model = weights = None
    checked_frames = []
    for frame,row in zip(frames,outcomes):
        try:
            require(row['source_index'] == frame['source_index'],'original frame identity')
            image = Image.open(io.BytesIO(verified(frame)))
            require(image.size == (640,480) and image.mode in ('I;16','I;16B','I'),'original 16-bit depth layout')
            raw = np.asarray(image,dtype=float)/5000.
            model,weights,checked = reconstruct_update(model,weights,raw,CAMERA,row['update'],reprojection,correspondence)
            checked_frames.append(dict(source_index=frame['source_index'],**checked,
                supported_model_pixels=int(np.sum(weights > 0)),maximum_model_weight=int(weights.max())))
        except (ValueError,AssertionError,KeyError,TypeError,IndexError) as error:
            write(output/'first-failure.json',dict(source_index=frame['source_index'],
                completed_frames=len(checked_frames),error_type=type(error).__name__,error=str(error),
                physical_accuracy_gates_changed=False))
            raise
        if len(checked_frames)%30 == 0:
            print(case,'raw-audited frames',len(checked_frames),flush=True)
    require(sum(v['iterations'] for v in checked_frames) == steps,'every reported solve raw-reconstructed')
    summary = dict(frames=180,updates=179,raw_iteration_equations=steps,
        returned_pose_equations=sum(v['final_equations'] for v in checked_frames),
        reference_view_warps=sum(v['model_replaced'] for v in checked_frames),
        fused_model_generations=179,exact_discrete_counts=True,ground_truth_decoded=False,
        physical_accuracy_claim=False)
    write(output/'audit.json',dict(pass_raw_mathematics=True,summary=summary,frames=checked_frames))
    print(case,json.dumps(summary),flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--analytic-only',action='store_true')
    parser.add_argument('--analytic-reports',type=Path,help='fresh reports from check-projective-depth.py; defaults to frozen originals')
    parser.add_argument('--recorded-reports',type=Path,help='fresh evaluator reports; defaults to frozen originals')
    parser.add_argument('--reprojection',choices=('point','tangent_plane'),default='point',help='policy for fresh analytic reports')
    parser.add_argument('--correspondence',choices=('forward','reciprocal'),default='forward')
    args = parser.parse_args()
    output = fresh(args.output)
    require(args.analytic_reports is not None or (args.reprojection=='point' and args.correspondence=='forward'),'frozen analytic reports use original policies')
    analytic(output,args.analytic_reports,args.reprojection,args.correspondence)
    cases = {}
    if not args.analytic_only:
        for case in ('tum-fr1-room-temporal','tum-fr1-desk2-independent'):
            folder = output/case
            folder.mkdir()
            cases[case] = recorded(case,folder,args.recorded_reports)
    write(output/'summary.json',dict(pass_raw_mathematics=True,cases=cases,
        ground_truth_decoded=False,physical_accuracy_improvement_claim=False,subjective_maturity_percent=20))


if __name__ == '__main__':
    main()
