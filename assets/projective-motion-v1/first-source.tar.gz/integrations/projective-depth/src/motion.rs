//! Causal SE(3) initialization from accepted depth-acquisition poses only.
use crate::{Pose, V, add, cross, mul, norm, sub};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum MotionModel {
    #[default]
    Stationary,
    ConstantVelocity,
}
#[derive(Debug, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Status {
    Bootstrap,
    Predicted,
    IncrementLimit,
    AmbiguousRotation,
}
#[derive(Debug, Serialize)]
pub struct Prediction {
    pub status: Status,
    pub previous_timestamp: Option<f64>,
    pub latest_timestamp: Option<f64>,
    pub history_interval_s: Option<f64>,
    pub horizon_s: Option<f64>,
    pub first_from_prediction: Option<Pose>,
}
#[derive(Default)]
pub(super) struct History {
    previous: Option<(f64, Pose)>,
    latest: Option<(f64, Pose)>,
}
impl History {
    pub(super) fn observe(&mut self, stamp: f64, pose: Pose) {
        debug_assert!(self.latest.is_none_or(|(t, _)| stamp > t));
        self.previous = self.latest;
        self.latest = Some((stamp, pose));
    }
    pub(super) fn predict(&self, stamp: f64) -> Prediction {
        let mut report = Prediction {
            status: Status::Bootstrap,
            previous_timestamp: self.previous.map(|p| p.0),
            latest_timestamp: self.latest.map(|p| p.0),
            history_interval_s: None,
            horizon_s: self.latest.map(|p| stamp - p.0),
            first_from_prediction: None,
        };
        let (Some((a, first)), Some((b, last))) = (self.previous, self.latest) else {
            return report;
        };
        let dt = b - a;
        report.history_interval_s = Some(dt);
        let Some(twist) = log_body(first.inverse().compose(last)) else {
            report.status = Status::AmbiguousRotation;
            return report;
        };
        let scaled = twist.map(|v| v * ((stamp - b) / dt));
        report.status = Status::IncrementLimit;
        if !scaled.iter().all(|v| v.is_finite()) || norm([scaled[3], scaled[4], scaled[5]]) > 0.15 {
            return report;
        }
        let increment = exp_body(scaled);
        if !increment.finite_rigid() || norm(increment.translation) > 0.1 {
            return report;
        }
        let predicted = last.compose(increment);
        if !predicted.finite_rigid() {
            return report;
        }
        report.status = Status::Predicted;
        report.first_from_prediction = Some(predicted);
        report
    }
}
fn log_body(p: Pose) -> Option<[f64; 6]> {
    let r = p.rotation;
    let skew = [
        (r[2][1] - r[1][2]) * 0.5,
        (r[0][2] - r[2][0]) * 0.5,
        (r[1][0] - r[0][1]) * 0.5,
    ];
    let sine = norm(skew);
    let cosine = ((r[0][0] + r[1][1] + r[2][2] - 1.) * 0.5).clamp(-1., 1.);
    let angle = sine.atan2(cosine);
    if angle > std::f64::consts::PI - 1e-6 {
        return None;
    }
    let w = if angle < 1e-8 {
        skew
    } else {
        mul(skew, angle / sine)
    };
    let coefficient = if angle < 1e-4 {
        1. / 12. + angle.powi(2) / 720. + angle.powi(4) / 30240.
    } else {
        (1. - 0.5 * angle / (0.5 * angle).tan()) / angle.powi(2)
    };
    let v = add(
        sub(p.translation, mul(cross(w, p.translation), 0.5)),
        mul(cross(w, cross(w, p.translation)), coefficient),
    );
    Some([v[0], v[1], v[2], w[0], w[1], w[2]])
}
fn exp_body(twist: [f64; 6]) -> Pose {
    let v: V = [twist[0], twist[1], twist[2]];
    let w = [twist[3], twist[4], twist[5]];
    let angle = norm(w);
    let (a, b) = if angle < 1e-4 {
        (
            0.5 - angle.powi(2) / 24. + angle.powi(4) / 720.,
            1. / 6. - angle.powi(2) / 120. + angle.powi(4) / 5040.,
        )
    } else {
        (
            (1. - angle.cos()) / angle.powi(2),
            (angle - angle.sin()) / angle.powi(3),
        )
    };
    let translation = add(add(v, mul(cross(w, v), a)), mul(cross(w, cross(w, v)), b));
    Pose {
        translation,
        ..Pose::identity().increment([0., 0., 0., w[0], w[1], w[2]])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn irregular_prediction_follows_a_helix_in_a_rotated_origin() {
        let origin = Pose::identity().increment([0.2, -0.1, 0.3, 0.1, -0.15, 0.2]);
        let arc = |s: f64| Pose {
            translation: [
                0.4 * (0.1 * s).sin(),
                0.4 * (1. - (0.1 * s).cos()),
                0.006 * s,
            ],
            ..Pose::identity().increment([0., 0., 0., 0., 0., 0.1 * s])
        };
        let mut history = History::default();
        history.observe(1., origin);
        history.observe(1.02, origin.compose(arc(1.)));
        let prediction = history.predict(1.03).first_from_prediction.unwrap();
        let error = origin.compose(arc(1.5)).inverse().compose(prediction);
        assert!(norm(error.translation) < 1e-12);
        for (a, b) in error
            .rotation
            .iter()
            .flatten()
            .zip(Pose::identity().rotation.iter().flatten())
        {
            assert!((a - b).abs() < 1e-12);
        }
    }
    #[test]
    fn bootstrap_bounds_and_ambiguous_rotation_never_invent_prediction() {
        let mut history = History::default();
        assert!(history.predict(1.).first_from_prediction.is_none());
        history.observe(1., Pose::identity());
        assert!(history.predict(1.02).first_from_prediction.is_none());
        history.observe(1.02, Pose::identity().increment([0.04, 0., 0., 0., 0., 0.]));
        assert!(matches!(history.predict(1.03).status, Status::Predicted));
        assert!(matches!(
            history.predict(1.1).status,
            Status::IncrementLimit
        ));
        let mut rotation = History::default();
        rotation.observe(1., Pose::identity());
        rotation.observe(
            1.02,
            Pose::identity().increment([0., 0., 0., std::f64::consts::PI, 0., 0.]),
        );
        assert!(matches!(
            rotation.predict(1.03).status,
            Status::AmbiguousRotation
        ));
    }
}
