//! Measured keyframe intensity complements the fused depth surface. No labels.
use crate::multireference::Gray;
use crate::{Equation, H, Level, Pose, cross, dot, norm, sub};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Photometric {
    #[default]
    Disabled,
    Keyframe,
}

#[derive(Clone, Debug, Serialize)]
pub struct PhotoEquation {
    pub count: usize,
    pub rms_gray: Option<f64>,
    pub used: bool,
    pub scale_m2_per_gray2: f64,
    pub h: H,
    pub g: [f64; 6],
}
#[derive(Debug, Serialize)]
pub struct PhotoState {
    pub source_timestamp: f64,
    pub reference_timestamp: Option<f64>,
    pub phase_qualified: bool,
}
pub(super) struct PhotoPair<'a> {
    pub target: &'a [Gray],
    pub source: &'a [Gray],
    pub enabled: bool,
}
impl PhotoPair<'_> {
    pub(super) fn equation(
        &self,
        target: &Level,
        source: &Level,
        pose: Pose,
        scale: usize,
    ) -> PhotoEquation {
        let mut out = PhotoEquation {
            count: 0,
            rms_gray: None,
            used: false,
            scale_m2_per_gray2: 0.005_f64.powi(2) / 100.,
            h: [[0.; 6]; 6],
            g: [0.; 6],
        };
        if !self.enabled {
            return out;
        }
        let level = match scale {
            4 => 0,
            2 => 1,
            _ => 2,
        };
        let stride = if scale == 1 { 2 } else { 1 };
        let mut squared = 0.;
        for y in (0..source.camera.height).step_by(stride) {
            for x in (0..source.camera.width).step_by(stride) {
                let i = y * source.camera.width + x;
                if dot(source.normals[i], source.normals[i]) <= 0.25 {
                    continue;
                }
                let q = pose.transform(source.vertices[i]);
                let Some(j) = target.camera.project(q, true) else {
                    continue;
                };
                let n = target.normals[j];
                if dot(n, n) <= 0.25
                    || norm(sub(q, target.vertices[j])) >= if scale == 4 { 0.12 } else { 0.08 }
                    || dot(pose.rotate(source.normals[i]), n) <= 0.8
                {
                    continue;
                }
                let c = target.camera;
                let z = q[2];
                let Some((value, gx, gy)) =
                    self.target[level].sample(c.fx * q[0] / z + c.cx, c.fy * q[1] / z + c.cy)
                else {
                    continue;
                };
                let residual = value - self.source[level].pixels[i];
                if residual.abs() >= 30. || gx.hypot(gy) < 1. {
                    continue;
                }
                let gradient = [
                    gx * c.fx / z,
                    gy * c.fy / z,
                    -(gx * c.fx * q[0] + gy * c.fy * q[1]) / (z * z),
                ];
                let rotation = cross(q, gradient);
                let jacobian = [
                    gradient[0],
                    gradient[1],
                    gradient[2],
                    rotation[0],
                    rotation[1],
                    rotation[2],
                ];
                let weight = (1. - (residual / 30.).powi(2)).powi(2);
                for a in 0..6 {
                    out.g[a] += jacobian[a] * residual * weight;
                    for b in 0..6 {
                        out.h[a][b] += jacobian[a] * jacobian[b] * weight;
                    }
                }
                out.count += 1;
                squared += residual * residual;
            }
        }
        if out.count > 0 {
            out.rms_gray = Some((squared / out.count as f64).sqrt());
        }
        out.used = out.count >= 200;
        out
    }
}
pub(super) fn combine(geometry: &Equation, photo: Option<&PhotoEquation>) -> (H, [f64; 6]) {
    let (mut h, mut g) = (geometry.h, geometry.g);
    if let Some(p) = photo
        && p.used
    {
        for a in 0..6 {
            g[a] += p.scale_m2_per_gray2 * p.g[a];
            for b in 0..6 {
                h[a][b] += p.scale_m2_per_gray2 * p.h[a][b];
            }
        }
    }
    (h, g)
}
