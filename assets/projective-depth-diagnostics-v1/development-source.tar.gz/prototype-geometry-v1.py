import json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image

def skew(v):
 x,y,z=v;return np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
def exp(v):
 a=np.linalg.norm(v);K=skew(v)
 return np.eye(3)+K if a<1e-12 else np.eye(3)+np.sin(a)/a*K+(1-np.cos(a))/(a*a)*(K@K)
def pyramid(raw):
 d=np.asarray(Image.open(raw),dtype=float)/5000.;layers={1:d}
 for s in [2,4]:
  a=layers[s//2];b=np.stack([a[dy::2,dx::2] for dy,dx in [(0,0),(0,1),(1,0),(1,1)]])
  low=b.min(axis=0);high=b.max(axis=0);v=b.mean(axis=0);v[(low<.3)|(high>5)|(high-low>.05+.01*low)]=0;layers[s]=v
 result={}
 for s in [4,2,1]:
  d=layers[s];h,w=d.shape;y,x=np.mgrid[:h,:w];f=525/s;cx=320/s-.5;cy=240/s-.5
  v=np.stack([(x-cx)*d/f,(y-cy)*d/f,d],axis=-1);n=np.zeros_like(v)
  a=v[1:-1,2:]-v[1:-1,:-2];b=v[2:,1:-1]-v[:-2,1:-1];cross=np.cross(a,b);norm=np.linalg.norm(cross,axis=-1)
  ok=(norm>1e-10)&(d[1:-1,1:-1]>.3)&(d[1:-1,1:-1]<5)
  for side in [d[1:-1,2:],d[1:-1,:-2],d[2:,1:-1],d[:-2,1:-1]]:ok&=(side>.3)&(abs(side-d[1:-1,1:-1])<.05+.01*d[1:-1,1:-1])
  n[1:-1,1:-1][ok]=cross[ok]/norm[ok,None]
  result[s]=(v,n,f,cx,cy)
 return result
def fit(previous,current):
 T=np.eye(4);detail=[]
 for s,iterations in [(4,10),(2,7),(1,5)]:
  v,n,f,cx,cy=previous[s];src,sn,*_=current[s];h,w=v.shape[:2]
  step=2 if s==1 else 1
  src=src[::step,::step].reshape(-1,3);sn=sn[::step,::step].reshape(-1,3);ok=np.linalg.norm(sn,axis=1)>.5;src=src[ok];sn=sn[ok]
  for it in range(iterations):
   p=src@T[:3,:3].T+T[:3,3];pn=sn@T[:3,:3].T
   zz=p[:,2];u=np.rint(f*p[:,0]/zz+cx).astype(int);vv=np.rint(f*p[:,1]/zz+cy).astype(int)
   mask=(zz>.3)&(u>=1)&(u<w-1)&(vv>=1)&(vv<h-1);ids=np.flatnonzero(mask);u=u[mask];vv=vv[mask]
   target=v[vv,u];normal=n[vv,u];dist=np.linalg.norm(p[ids]-target,axis=1)
   valid=(np.linalg.norm(normal,axis=1)>.5)&(dist<.12 if s==4 else dist<.08)&(np.sum(pn[ids]*normal,axis=1)>.8)
   ids=ids[valid];target=target[valid];normal=normal[valid];query=p[ids]
   if len(ids)<200:raise ValueError('support '+str(len(ids)))
   r=np.sum(normal*(query-target),axis=1);J=np.column_stack([normal,np.cross(query,normal)]);weight=np.minimum(1.,.01/np.maximum(abs(r),1e-15))
   H=J.T@(J*weight[:,None]);g=J.T@(r*weight);scale=np.sqrt(np.diag(H));A=H/scale[:,None]/scale[None,:];eig=np.linalg.eigvalsh(A)
   if eig[0]<eig[-1]/1e6:raise ValueError('condition')
   d=np.linalg.solve(A,-g/scale)/scale
   if np.linalg.norm(d[:3])>.1 or np.linalg.norm(d[3:])>.15:raise ValueError('step')
   E=exp(d[3:]);T[:3,3]=E@T[:3,3]+d[:3];T[:3,:3]=E@T[:3,:3]
   if np.linalg.norm(d[:3])<1e-5 and np.linalg.norm(d[3:])<1e-5:break
  detail.append([s,len(ids),float(np.sqrt(np.mean(r*r))),float(eig[-1]/eig[0])])
 if detail[-1][2]>.03 or np.linalg.norm(T[:3,3])>.5:raise ValueError('residual or jump')
 return T,detail
def qr(q):
 q=q/np.linalg.norm(q);x,y,z,w=q;return np.eye(3)+2*w*skew(q[:3])+2*skew(q[:3])@skew(q[:3])
def reference(rows,t):
 k=np.searchsorted(rows[:,0],t)
 if k==0 or k==len(rows):raise ValueError('GT bracket')
 a,b=rows[k-1],rows[k];alpha=(t-a[0])/(b[0]-a[0]);qa,qb=a[4:],b[4:];dot=qa@qb
 if dot<0:qb=-qb;dot=-dot
 if dot>.9995:q=(1-alpha)*qa+alpha*qb
 else:
  angle=np.arccos(np.clip(dot,-1,1));q=(np.sin((1-alpha)*angle)*qa+np.sin(alpha*angle)*qb)/np.sin(angle)
 T=np.eye(4);T[:3,:3]=qr(q);T[:3,3]=(1-alpha)*a[1:4]+alpha*b[1:4];return T
def run(dataset):
 base=Path('data')/dataset;m=json.loads((base/'manifest.json').read_text());frames=m['frames'];root=np.eye(4);last=frames[0]['depth_timestamp'];previous=pyramid(base/'raw'/frames[0]['depth_file']);out=[];lost=False
 for frame in frames[1:]:
  begin=time.perf_counter();stamp=frame['depth_timestamp'];item={'index':frame['source_index'],'stamp':stamp,'accepted':False}
  if stamp-last>.2:lost=True
  try:
   if lost:raise ValueError('lost')
   current=pyramid(base/'raw'/frame['depth_file']);relative,trace=fit(previous,current);root=root@relative;previous=current;last=stamp;item.update(accepted=True,root=root.tolist(),trace=trace)
  except ValueError as e:item['failure']=str(e)
  item['elapsed']=time.perf_counter()-begin;out.append(item)
  if len(out)%30==0:print(dataset,len(out),sum(x['accepted'] for x in out),flush=True)
 labels=np.loadtxt(base/'raw/groundtruth.txt',comments='#');origin=reference(labels,frames[0]['depth_timestamp']);truth0=np.linalg.inv(origin)
 for item in out:
  if not item['accepted']:continue
  truth=truth0@reference(labels,item['stamp']);estimate=np.array(item['root']);pos=np.linalg.norm(truth[:3,3]-estimate[:3,3]);rot=np.arccos(np.clip((np.trace(truth[:3,:3].T@estimate[:3,:3])-1)/2,-1,1));item.update(position_error_m=pos,rotation_error_rad=rot,accurate=bool(pos<=.1 and rot<=.1))
 summary={'accepted':sum(x['accepted'] for x in out),'accurate':sum(x.get('accurate',False) for x in out),'total':len(out),'lost':lost,'max_position':max([x.get('position_error_m',0) for x in out]),'max_rotation':max([x.get('rotation_error_rad',0) for x in out])};print(dataset,summary,flush=True)
 Path('artifacts/projective-odometry-dev/'+dataset+'-geometry-v1.json').write_text(json.dumps({'summary':summary,'frames':out},indent=2)+'\n')
for name in sys.argv[1:]:run(name)
