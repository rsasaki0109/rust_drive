import gzip,hashlib,importlib.util,io,json,tarfile
from pathlib import Path
import numpy as np
base=Path('artifacts/projective-odometry-dev')
output=Path('assets/projective-depth-diagnostics-v1')
output.mkdir()
spec=importlib.util.spec_from_file_location('independent','scripts/check-opencv-rgbd.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
cases=('tum-fr1-room-temporal','tum-fr1-desk2-independent')
variants=('geometry-v1','keyframe-v2','hybrid-v3','hybrid-long-anchor-v4','bilateral-v5','fused-v6')
summary={}
source_paths={p.name:p for p in base.glob('prototype-*.py')}
source_paths.update({name:Path('scripts')/name for name in ('compare-opencv-rgbd.py','check-opencv-rgbd.py','requirements-opencv-reference.txt','requirements-visual.txt')})
source_paths['compare-opencv-rgbd-first.py']=base/'opencv-reference-first/compare-opencv-rgbd-first.py'
source_paths['preserve-evidence.py']=Path(__file__)
source_paths['preserve-evidence-first.py']=base/'preserve-evidence-first.py'
ctx={case:audit.context(case,base/'opencv-reference-final'/case) for case in cases}
for variant in variants:
 summary[variant]={}
 for case in cases:
  path=base/(case+'-'+variant+'.json');data=json.loads(path.read_text());frames,truths,_=ctx[case]
  assert len(data['frames'])==179
  good=0;errors=[];independent_scores=[];label_deltas=[];last=frames[0]['depth_timestamp'];lost=False
  for frame,item,truth in zip(frames[1:],data['frames'],truths):
   assert item['index']==frame['source_index'] and item['stamp']==frame['depth_timestamp']
   lost |= item['stamp']-last>.2
   assert not(lost and item['accepted'])
   if not item['accepted']:continue
   last=item['stamp'];pose=np.asarray(item['root']);assert pose.shape==(4,4) and np.isfinite(pose).all()
   np.testing.assert_allclose(pose[:3,:3].T@pose[:3,:3],np.eye(3),atol=1e-8,rtol=0)
   assert abs(np.linalg.det(pose[:3,:3])-1)<1e-8
   position=float(np.linalg.norm(pose[:3,3]-truth[:3,3]));r=truth[:3,:3].T@pose[:3,:3]
   angle=float(np.arccos(np.clip((np.trace(r)-1)/2,-1,1)))
   label_deltas.append((abs(position-item['position_error_m']),abs(angle-item['rotation_error_rad'])))
   independent_scores.append(dict(source_index=item['index'],independent_position_error_m=position,independent_rotation_error_rad=angle,original_position_error_m=item['position_error_m'],original_rotation_error_rad=item['rotation_error_rad']))
   accurate=position<=.1 and angle<=.1;assert accurate==item['accurate'];good+=accurate;errors.append((position,angle))
  checked=dict(total_updates=179,accepted=len(errors),root_accurate=good,lost=lost,max_position_error_m=max(e[0] for e in errors),max_rotation_error_rad=max(e[1] for e in errors),complete_accuracy_pass=good==179 and not lost)
  assert len(errors)==data['summary']['accepted'] and good==data['summary']['accurate'] and lost==data['summary']['lost']
  checked['original_max_position_error_m']=data['summary']['max_position']
  checked['original_max_rotation_error_rad']=data['summary']['max_rotation']
  checked['maximum_position_label_delta_m']=max(e[0] for e in label_deltas)
  checked['maximum_rotation_label_delta_rad']=max(e[1] for e in label_deltas)
  checked['accuracy_classifications_changed']=0
  (output/('independent-scores-'+case+'-'+variant+'.json.gz')).write_bytes(gzip.compress((json.dumps(independent_scores,indent=2)+'\n').encode(),mtime=0))
  summary[variant][case]=checked
  (output/path.with_suffix('.json.gz').name).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for label,folder in [('first',base/'opencv-reference-first'),('final',base/'opencv-reference-final')]:
 for path in folder.rglob('*.json'):
  target=output/('opencv-'+label)/path.relative_to(folder)
  target.parent.mkdir(parents=True,exist_ok=True)
  target.with_suffix('.json.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for name in ('design.json','fusion-v6-design.json','repeat-review.json','opencv-final-source-audit.json','preservation-diagnosis.json'):
 (output/name).write_bytes((base/name).read_bytes())
with (output/'development-source.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,path in sorted(source_paths.items()):
    body=path.read_bytes();item=tarfile.TarInfo(name);item.size=len(body);item.mtime=0;item.mode=0o644
    archive.addfile(item,io.BytesIO(body))
receipt=dict(role='already viewed development experiments; none is a held-out quality success',prototype_summaries=summary,operational_reference=audit.document(base/'opencv-reference-final/comparison.json'),audited_updates=12*179,source_sha256={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(source_paths.items())},scope='Independent reference interpolation, root scores, acquisition identity and expiry. Does not independently reconstruct prototype image pyramids, ICP residuals or map fusion.',original_source_and_labels_unchanged=True,subjective_maturity_percent=20,requested_30_percent_reached=False)
(output/'review.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps(summary,indent=2))
