# Native depth policies and continuous regression gate

**No accuracy improvement is adopted.** Four changes were implemented in the
maintained Rust tracker and evaluated over both complete 179-update recordings.
None meets the acceptance rule fixed before fitting. The default remains point
reprojection, forward nearest-pixel matching and target-plane residuals, with
**64/179 room and 161/179 desk2** root-accurate updates.

This work adds configurable native implementations, raw reconstruction and a
reusable adoption checker. It does not resolve sustained localization accuracy
or add a driving capability. Earlier local-window convergence results are not
used as substitutes for these complete physical trajectories.

## Complete outcomes

All configurations accept all 179 updates in each recording without expiry or
resets. Every complete accuracy protocol still fails. Counts use the original
**0.1 m / 0.1 rad** first-camera root gates and include all rejected or inaccurate
updates in the denominator. Values below compare the same viewed depth indices
100–279, calibration and acquisition timestamps.

| Native configuration | Room accurate / 179 | Desk2 accurate / 179 | Max position error, room / desk2 (m) | Max rotation error, room / desk2 (rad) |
|---|---:|---:|---|---|
| Original default | 64 | 161 | 0.296290 / 0.114800 | 0.141286 / 0.090386 |
| Tangent-plane model reprojection | 64 | 162 | 0.299407 / 0.113487 | 0.142044 / 0.090094 |
| Reciprocal pixel matching | 60 | 161 | 0.296900 / 0.115724 | 0.141722 / 0.093232 |
| Symmetric measured-plane residuals | 62 | 79 | 0.297918 / 0.204397 | 0.145455 / 0.338936 |
| Bilinear target sampling | 64 | 159 | 0.295584 / 0.126713 | 0.140018 / 0.090489 |

Tangent reprojection slightly improves desk2 while worsening room's maximum
errors. Reciprocal matching worsens room and maximum errors. Symmetric residuals
substantially worsen desk2. Bilinear sampling reduces room's maximum errors but
loses two desk2 accurate updates. No candidate improves room's accurate count.
The baseline and every attempted result remain preserved.

The [retained comparison](../assets/projective-reprojection-v1/summary.json)
and [validation receipt](../assets/projective-reprojection-v1/validation.json)
link the complete source-bound results.

The adoption rule requires room accuracy above 64, desk2 at least 161, all 179
updates accepted in each without loss, and no worse maximum position or rotation
error in either recording. Mathematical checks and default-interface regression
must also pass. Full 179/179 physical accuracy is reported separately; a passing
relative adoption gate would not establish that stronger requirement.

## Rust API and transport

The existing `Tracker::new(camera)` and camera-only JSON `Configure` keep their
original behavior. The current default binary reproduces **all 360 original
sensor outcomes exactly**, including poses, equations, fusion and clocks.

`Tracker::with_config(camera, TrackerConfig)` explicitly selects experimental
policies. The default configuration is equivalent to:

```rust
TrackerConfig {
    reprojection: Reprojection::Point,
    correspondence: Correspondence::Forward,
    residual: Residual::TargetPlane,
}
```

The JSON-lines `Configure` request accepts optional `reprojection`,
`correspondence` and `residual` fields with the names below. Missing fields use
the original defaults; unknown fields and enum values reject. The version-1
acknowledgment, frame limits, optical coordinate convention and metre/second
units are unchanged. There are no new dependencies or Cargo lockfile changes.

* `reprojection`: `point` or `tangent_plane`. The latter intersects a rounded
  destination ray with the transformed measured tangent plane during fusion
  and model-view warps. Missing normals, grazing rays, out-of-range depths or
  corrections outside the existing fusion band retain the original point
  splat. `tangent_adjusted` counts adjusted projected samples when nonzero;
  it is not a count of unique target pixels or additional measurements.
* `correspondence`: `forward`, `reciprocal` or `bilinear`. Reciprocal matching
  requires a selected target to project back to the original sampled source
  pixel. Bilinear sampling requires four valid depths/normals, bounded depth
  spread and a nondegenerate blended normal; missing corners and discontinuities
  reject without filling or nearest-pixel fallback.
* `residual`: `target_plane` or `symmetric_planes`. Symmetric fitting averages
  two Huber losses. The source-plane Jacobian includes rotation of its normal,
  giving a target-point lever arm. Its RMS averages the two squared residuals
  per correspondence, which is counted once. This option is not recommended
  by the recorded comparison.

Only the individual configurations in the table have recorded trajectory
results. Their combinations have no physical accuracy qualification. All modes
retain bounded pyramid work, normal/distance/support/condition/increment guards,
accepted acquisition clocks, atomic failure behavior and latched expiry.
They remain offline research, outside vehicle localization and controls.

## Reproduction and automatic rejection of regressions

Use the original [room/desk2 inputs and tool environment](projective-depth-rust.md#reproduction).
Select fresh output directories. For example, compare the baseline with bilinear
target sampling:

```bash
source scripts/env.sh
cargo build --release --locked --manifest-path integrations/projective-depth/Cargo.toml
OPENBLAS_NUM_THREADS=1 python scripts/evaluate-projective-depth.py \
  --binary integrations/projective-depth/target/release/rustdriving-projective-depth \
  --output artifacts/native-baseline
OPENBLAS_NUM_THREADS=1 python scripts/evaluate-projective-depth.py \
  --binary integrations/projective-depth/target/release/rustdriving-projective-depth \
  --correspondence bilinear --output artifacts/native-bilinear
OPENBLAS_NUM_THREADS=1 python scripts/check-projective-depth.py \
  --binary integrations/projective-depth/target/release/rustdriving-projective-depth \
  --correspondence bilinear --output artifacts/native-bilinear-analytic
OPENBLAS_NUM_THREADS=1 python scripts/audit-projective-depth-raw.py \
  --analytic-reports artifacts/native-bilinear-analytic --correspondence bilinear \
  --recorded-reports artifacts/native-bilinear --output artifacts/native-bilinear-raw
OPENBLAS_NUM_THREADS=1 python scripts/check-projective-depth-comparison.py \
  --baseline artifacts/native-baseline --candidate artifacts/native-bilinear \
  --raw-audit artifacts/native-bilinear-raw --output artifacts/native-bilinear-gate.json
```

Both evaluators exit **1** after saving these complete physical failures. The
comparison checker also saves its result and exits **1** when adoption fails;
this differs from a transport or mathematical-audit error. Run these commands
separately rather than chaining later checks on a quality exit code of zero.

The comparison checker binds the baseline to the original archived native sensor
ledger, checks identical inputs/calibration and no resets, verifies the scored
updates against the pre-label ledger, and recomputes all root classifications.
It uses an `atan2` rotation check; reference interpolation is shared with the
existing qualified reference helper. It also binds the raw audit to the exact
candidate freeze and sensor-ledger hashes. Changed counts, poses, gates or
unrelated audit files cannot supply a passing result.

## Validation and limits

All four candidates retain their sources and full first outcomes. The original
source and binary were saved before editing the maintained Rust component.
Historical source-bound experiments retain their original archives and reports;
replaying those versions requires their archived sources rather than replacing
their recorded source hashes with hashes of the updated component.
Numeric labels enter scoring only after every operational outcome in a recording
has been written. Hash-qualified PNGs, axial-Z `/5000` conversion, first optical
origin and acquisition timestamps remain unchanged. These are viewed indoor
development records, without held-out or automotive generalization.

Independent raw reconstruction checks **28,036 fitted equations plus 1,432
returned-pose equations**, rebuilding all 1,432 prescribed candidate model
generations. Counts and fusion categories agree exactly. The four full comparisons
reuse the same observations. They do not represent four independent acquisitions.

The optional Rust crate passes **23 tests**, including a transformed-plane
witness, missing/grazing-normal fallback, an incorrect reverse-pixel witness,
all six source-normal Jacobian axes and missing bilinear support. Each policy
also passes four known-motion checks, malformed-input/clock/expiry checks and
report-corruption controls. CI runs the analytic checks without downloading
recordings. The existing supervisor's analytic checks pass.

Core checks pass **371 Rust tests and 49 scenarios with sensor-log replays**.
No driving pipeline or vehicle integration was changed. The original accuracy
failure remains the open problem; subjective maturity stays **about 20%** versus
mature driving OSS. Test counts alone do not justify increasing it.
