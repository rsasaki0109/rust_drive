#!/usr/bin/env python3
"""Independent ray-cast motion controls and bounded transport checks for Rust depth fusion."""
import argparse
import copy
import json
from pathlib import Path
import subprocess

import numpy as np
from projective_depth_common import Client, audit_iterations, audit_sequence, exp_rotation, fresh, pose, require, sha, write

CAMERA = dict(width=160,height=120,fx=130.,fy=130.,cx=79.5,cy=59.5)


def render(transform):
    y,x = np.mgrid[:120,:160]
    rays = np.stack([(x-79.5)/130,(y-59.5)/130,np.ones_like(x)],axis=-1)
    direction = rays@transform[:3,:3].T
    origin = transform[:3,3]
    depth = (4-origin[2])/direction[:,:,2]
    for center,radius in (([-.5,-.2,2.2],.4),([.5,.3,2.8],.5),([.1,-.5,3.2],.4)):
        offset = origin-np.array(center)
        a = np.sum(direction*direction,axis=-1)
        b = 2*np.sum(direction*offset,axis=-1)
        discriminant = b*b-4*a*(offset@offset-radius*radius)
        intersection = (-b-np.sqrt(np.maximum(0,discriminant)))/(2*a)
        visible = (discriminant > 0)&(intersection > 0)&(intersection < depth)
        depth[visible] = intersection[visible]
    return depth


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--reprojection',choices=('point','tangent_plane'),default='point')
    parser.add_argument('--correspondence',choices=('forward','reciprocal','bilinear'),default='forward')
    parser.add_argument('--residual',choices=('target_plane','symmetric_planes'),default='target_plane')
    parser.add_argument('--normals',choices=('central_difference','inverse_depth_plane'),default='central_difference')
    args = parser.parse_args()
    output = fresh(args.output)
    binary = args.binary.absolute()
    cases = []
    corruption_names = []
    for axis,angle,translation in ((0,0.,[0.,0.,0.]),(0,-.02,[-.01,.02,.01]),
                                   (1,.02,[.02,-.01,.01]),(2,.02,[.01,.01,-.02])):
        transform = np.eye(4)
        vector = np.zeros(3)
        vector[axis] = angle
        transform[:3,:3],transform[:3,3] = exp_rotation(vector),translation
        client = Client(binary,CAMERA,configuration=dict(reprojection=args.reprojection,correspondence=args.correspondence,residual=args.residual,normals=args.normals))
        try:
            initial = client.frame(1.,render(np.eye(4)))
            require(initial['accepted'],'analytic initialization')
            result = client.frame(1.03,render(transform))
            require(result['accepted'],'analytic motion fit')
            steps = audit_iterations(result)
            estimate = pose(result['first_from_current'])
            position = float(np.linalg.norm(estimate[:3,3]-transform[:3,3]))
            rotation = float(np.arccos(np.clip((np.trace(transform[:3,:3].T@estimate[:3,:3])-1)/2,-1,1)))
            require(position <= .004 and rotation <= .004,'analytic direction/metre/rotation accuracy')
            duplicate = client.frame(1.03,render(transform))
            require(not duplicate['accepted'] and duplicate['last_accepted_timestamp'] == 1.03,'duplicate cannot renew pose')
            failure = client.frame(1.1,np.zeros((120,160)))
            require(not failure['accepted'] and failure['last_accepted_timestamp'] == 1.03,'failed fit cannot renew pose')
            expired = client.frame(1.231,np.zeros((120,160)))
            recovery = client.frame(1.24,render(transform))
            require(expired['lost'] and recovery['lost'] and not recovery['accepted'],'expired pose has no implicit reset')
            client.finish()
        except BaseException:
            client.abort()
            raise
        cases.append(dict(axis=axis,angle_rad=angle,known_first_from_current=transform.tolist(),
                          position_error_m=position,rotation_error_rad=rotation,checked_normal_steps=steps))
        write(output/('motion-'+str(len(cases))+'.json'),dict(result=result,expected=transform.tolist()))
        baseline = [dict(update=initial),dict(update=result)]
        audit_sequence(baseline,[1.,1.03])
        if angle == 0:
            def corrupt(name, change):
                modified = copy.deepcopy(baseline)
                change(modified[1]['update'])
                try:
                    audit_sequence(modified,[1.,1.03])
                except (ValueError,AssertionError,KeyError,IndexError,TypeError):
                    corruption_names.append(name)
                else:
                    raise ValueError('undetected corruption: '+name)
            corrupt('wrong normal solve',lambda u:u['iterations'][0]['delta'].__setitem__(0,.05))
            corrupt('wrong increment pose',lambda u:u['iterations'][0]['after']['translation'].__setitem__(0,.05))
            corrupt('altered root composition',lambda u:u['first_from_current']['translation'].__setitem__(0,.05))
            corrupt('missing support',lambda u:u['iterations'][0]['equation'].update(count=199))
            corrupt('returned-pose residual exceeds gate',lambda u:u['final_equation'].update(rms_m=.1))
            corrupt('lost fusion assignment',lambda u:u['fusion'].update(averaged=0))
            corrupt('wrong keyframe switch',lambda u:u.update(keyframe_replaced=True))
            corrupt('false accepted clock',lambda u:u.update(last_accepted_timestamp=1.))
            corrupt('wrong acquisition',lambda u:u.update(timestamp=1.04))
            corrupt('false loss state',lambda u:u.update(lost=True))
    config = json.dumps(dict(kind='Configure',camera=CAMERA))+'\n'
    malformed = {
        'missing configuration':json.dumps(dict(kind='Frame',timestamp=1.,depth_m=[]))+'\n',
        'duplicate configuration':config+config,
        'unknown request field':json.dumps(dict(kind='Configure',camera=CAMERA,truth=[]))+'\n',
        'oversized camera':json.dumps(dict(kind='Configure',camera=dict(CAMERA,width=644)))+'\n',
        'invalid focal length':json.dumps(dict(kind='Configure',camera=dict(CAMERA,fx=0.)))+'\n',
        'unknown reprojection':json.dumps(dict(kind='Configure',camera=CAMERA,reprojection='unknown'))+'\n',
        'unknown correspondence':json.dumps(dict(kind='Configure',camera=CAMERA,correspondence='unknown'))+'\n',
        'unknown residual':json.dumps(dict(kind='Configure',camera=CAMERA,residual='unknown'))+'\n',
        'unknown normal estimation':json.dumps(dict(kind='Configure',camera=CAMERA,normals='unknown'))+'\n',
        'missing final newline':config.rstrip('\n'),
        'no frame':config,
        'oversized request':' '*(8*1024*1024+1)+'\n',
        'nonfinite JSON':config+'{"kind":"Frame","timestamp":NaN,"depth_m":[]}\n',
        'frame cap':config+''.join(json.dumps(dict(kind='Frame',timestamp=1.+i*.03,depth_m=[]))+'\n' for i in range(201)),
    }
    for name,body in malformed.items():
        result = subprocess.run([str(binary)],input=body,text=True,capture_output=True,timeout=30)
        require(result.returncode == 2 and bool(result.stderr),'transport rejection: '+name)
    write(output/'summary.json',dict(analytic_controls_pass=True,translation_gate_m=.004,rotation_gate_rad=.004,
        motions=cases,reprojection=args.reprojection,correspondence=args.correspondence,residual=args.residual,rejected_transport_cases=list(malformed),binary_sha256=sha(binary.read_bytes()),
        rejected_report_corruptions=corruption_names,
        checker_sha256=sha(Path(__file__).read_bytes()),
        scope='analytic geometry and independent linear algebra; no physical accuracy or real-time claim'))


if __name__ == '__main__':
    main()
