import hashlib,importlib.util,io,json
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path('/workspace/rust_drive');BASE=ROOT/'artifacts/multireference-rgbd-dev'
spec=importlib.util.spec_from_file_location('phase',ROOT/'artifacts/phase-aware-rgbd-dev/prototype.py');phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase);geo=phase.geo

def fit(references,current,current_i,initial,enabled,phase_offset):
 T=initial.copy();trace=[]
 for scale,cap,stride in [(4,10,1),(2,7,2),(1,5,4)]:
  xyz,normals,*_=current[scale];src=xyz[::stride,::stride].reshape(-1,3);sn=normals[::stride,::stride].reshape(-1,3);ci=current_i[scale][::stride,::stride].ravel();ok=np.linalg.norm(sn,axis=1)>.5;src,sn,ci=src[ok],sn[ok],ci[ok]
  for it in range(cap+1):
   root_points=src@T[:3,:3].T+T[:3,3];root_normals=sn@T[:3,:3].T;H=np.zeros((6,6));g=np.zeros(6);squared=0.;count=0;photo_count=0
   for ref in references:
    pose=ref['root'];point=(root_points-pose[:3,3])@pose[:3,:3];v,n,f,cx,cy=ref['surface'][scale];h,w=v.shape[:2];z=point[:,2];uf=f*point[:,0]/z+cx;vf=f*point[:,1]/z+cy;u=np.rint(uf).astype(int);vv=np.rint(vf).astype(int);inside=(z>.3)&(u>=1)&(u<w-1)&(vv>=1)&(vv<h-1);ids=np.flatnonzero(inside);u=u[inside];vv=vv[inside];target=v[vv,u];normal=n[vv,u];normal_root=normal@pose[:3,:3].T
    ok=(np.linalg.norm(normal,axis=1)>.5)&(np.linalg.norm(point[ids]-target,axis=1)<(.12 if scale==4 else .08))&(np.sum(root_normals[ids]*normal_root,axis=1)>.8);ids=ids[ok];target,normal,normal_root=target[ok],normal[ok],normal_root[ok]
    if not len(ids):continue
    r=np.sum(normal*(point[ids]-target),axis=1);J=np.column_stack([normal_root,np.cross(root_points[ids],normal_root)]);weight=np.minimum(1.,.01/np.maximum(abs(r),1e-15));H+=J.T@(weight[:,None]*J)/.005**2;g+=J.T@(weight*r)/.005**2;squared+=float(r@r);count+=len(r)
    if enabled and abs(phase_offset-ref['phase'])<=.005:
     intensity,ix,iy=phase.sample(ref['gray'][scale],uf[ids],vf[ids]);pr=intensity-ci[ids];ok=(abs(pr)<30)&(np.hypot(ix,iy)>=1.)
     if ok.sum()>=200:
      q=point[ids[ok]];zz=q[:,2];dx,dy=ix[ok],iy[ok];grad_target=np.column_stack([dx*f/zz,dy*f/zz,-f*(dx*q[:,0]+dy*q[:,1])/(zz*zz)]);grad_root=grad_target@pose[:3,:3].T;JP=np.column_stack([grad_root,np.cross(root_points[ids[ok]],grad_root)]);pr=pr[ok];wp=(1-(pr/30)**2)**2;H+=JP.T@(wp[:,None]*JP)/100.;g+=JP.T@(wp*pr)/100.;photo_count+=len(pr)
   if count<200:raise ValueError('support')
   rms=np.sqrt(squared/count)
   if it==cap:break
   diagonal=np.sqrt(np.diag(H));A=H/diagonal[:,None]/diagonal[None,:];eig=np.linalg.eigvalsh(A)
   if eig[0]<=0 or eig[-1]/eig[0]>1e6:raise ValueError('condition')
   delta=np.linalg.solve(A,-g/diagonal)/diagonal
   if np.linalg.norm(delta[:3])>.1 or np.linalg.norm(delta[3:])>.15:raise ValueError('increment')
   E=geo.exp(delta[3:]);T[:3,3]=E@T[:3,3]+delta[:3];T[:3,:3]=E@T[:3,:3];trace.append(dict(scale=scale,support=count,rms_m=float(rms),photo_support=photo_count,condition=float(eig[-1]/eig[0])))
   if np.linalg.norm(delta[:3])<1e-5 and np.linalg.norm(delta[3:])<1e-5:
    # Extra evaluation at the returned pose, not the previous iterate.
    cap=it+1
  final_rms=float(rms)
 if final_rms>.03:raise ValueError('final residual')
 return T,trace

def operational(case,branch,out):
 folder=ROOT/'data'/case;manifest_body=(folder/'manifest.json').read_bytes();m=json.loads(manifest_body);frames=m['frames'];inventory={v['file']:v for v in m['files']}
 def verified(name):
  body=(folder/'raw'/name).read_bytes();pin=inventory[name];assert len(body)==pin['bytes'] and phase.sha(body)==pin['sha256'];return body
 for name in inventory:verified(name)
 phase.write(out/'freeze.json',dict(branch=branch,manifest_sha256=phase.sha(manifest_body),source_sha256=phase.sha(Path(__file__).read_bytes()),design_sha256=phase.sha((ROOT/'assets/multireference-rgbd-v1/design.json').read_bytes()),inputs={n:v['sha256'] for n,v in inventory.items()},ground_truth_operational=False))
 def load(frame,root):
  d=np.asarray(Image.open(io.BytesIO(verified(frame['depth_file']))),dtype=float)/5000.;color=np.asarray(Image.open(io.BytesIO(verified(frame['rgb_file']))),dtype=np.uint32);gray=((77*color[:,:,0]+150*color[:,:,1]+29*color[:,:,2])>>8).astype(float);assert d.shape==(480,640) and gray.shape==(480,640)
  return dict(surface=geo.pyramid(d),gray=phase.images(gray),root=root.copy(),phase=frame['rgb_timestamp']-frame['depth_timestamp'],index=frame['source_index'])
 root=np.eye(4);first=load(frames[0],root);keys=[first];latest=first;last=frames[0]['depth_timestamp'];observed_rgb=frames[0]['rgb_timestamp'];lost=False;rows=[]
 for frame in frames[1:]:
  stamp=frame['depth_timestamp'];enabled=branch=='phase-gated-rgbd' and frame['rgb_timestamp']>observed_rgb;observed_rgb=frame['rgb_timestamp'];row=dict(source_index=frame['source_index'],stamp=stamp,accepted=False)
  if stamp-last>.2:lost=True
  try:
   if lost:raise ValueError('lost')
   current=load(frame,root);references=list(keys)
   if latest['index'] not in [r['index'] for r in references]:references.append(latest)
   assert len(references)<=5
   estimate,trace=fit(references,current['surface'],current['gray'],root,enabled,current['phase']);relative=np.linalg.inv(root)@estimate
   if np.linalg.norm(relative[:3,3])>.5:raise ValueError('relative jump')
   current['root']=estimate.copy();delta=np.linalg.inv(keys[-1]['root'])@estimate;replace=np.linalg.norm(delta[:3,3])>.1 or np.arccos(np.clip((np.trace(delta[:3,:3])-1)/2,-1,1))>.1
   if replace:keys=[first,*keys[1:],current][-4:] if len(keys)>1 else [first,current];keys=[first]+[r for r in keys if r['index']!=first['index']][-3:]
   row.update(accepted=True,root=estimate.tolist(),trace=trace,references=[r['index'] for r in references],keyframe_replaced=bool(replace));root=estimate;latest=current;last=stamp
  except ValueError as error:row['rejection']=str(error)
  rows.append(row)
  if len(rows)%30==0:print(case,branch,len(rows),flush=True)
 phase.write(out/'sensor-only.json',dict(frames=rows,lost=lost,ground_truth_parsed=False));return frames,rows,lost,verified

def main():
 output=BASE/'first';output.mkdir();saved={}
 for case in ['tum-fr1-room-temporal','tum-fr1-desk2-independent']:
  for branch in ['geometry-only','phase-gated-rgbd']:
   out=output/(case+'-'+branch);out.mkdir();saved[(case,branch)]=operational(case,branch,out)
 spec=importlib.util.spec_from_file_location('reference',ROOT/'scripts/check-opencv-rgbd.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref);ref.controls();summaries={}
 for (case,branch),(frames,rows,lost,verified) in saved.items():
  labels=np.loadtxt(io.BytesIO(verified('groundtruth.txt')),comments='#');assert labels.ndim==2 and labels.shape[1]==8 and np.isfinite(labels).all() and np.all(np.diff(labels[:,0])>0);origin=np.linalg.inv(ref.truth_at(labels,frames[0]['depth_timestamp']));errors=[]
  for row in rows:
   if not row['accepted']:continue
   estimate=np.array(row['root']);truth=origin@ref.truth_at(labels,row['stamp']);p=float(np.linalg.norm(estimate[:3,3]-truth[:3,3]));a=float(np.arccos(np.clip((np.trace(truth[:3,:3].T@estimate[:3,:3])-1)/2,-1,1)));row.update(position_error_m=p,rotation_error_rad=a,accurate=p<=.1 and a<=.1);errors.append((p,a))
  summary=dict(total_updates=179,accepted=len(errors),root_accurate=sum(r.get('accurate',False) for r in rows),lost=lost,max_position_error_m=max(v[0] for v in errors),max_rotation_error_rad=max(v[1] for v in errors));name=case+'-'+branch;summaries[name]=summary;phase.write(output/name/'results.json',dict(summary=summary,frames=rows));print(name,json.dumps(summary),flush=True)
 phase.write(output/'summary.json',summaries)
if __name__=='__main__':main()
