"""Independent vectorized depth geometry; never imports an operational Rust/Python fitter."""
import numpy as np

from projective_depth_common import pose, require


def vertices(depth, camera):
    y,x = np.indices(depth.shape)
    return np.stack([(x-camera['cx'])*depth/camera['fx'],
                     (y-camera['cy'])*depth/camera['fy'],depth],axis=-1)


def pyramid(raw, camera):
    depths = {1:raw.copy()}
    for scale in (2,4):
        a = depths[scale//2]
        block = np.stack([a[dy::2,dx::2] for dy,dx in ((0,0),(0,1),(1,0),(1,1))])
        lo,hi = block.min(axis=0),block.max(axis=0)
        valid = (lo >= .3)&(hi <= 5)&(hi-lo <= .05+.01*lo)
        depths[scale] = np.where(valid,block.mean(axis=0),0.)
    result = {}
    for scale,depth in depths.items():
        c = dict(width=camera['width']//scale,height=camera['height']//scale,
                 fx=camera['fx']/scale,fy=camera['fy']/scale,
                 cx=(camera['cx']+.5)/scale-.5,cy=(camera['cy']+.5)/scale-.5)
        xyz = vertices(depth,c)
        normal = np.zeros_like(xyz)
        center = depth[1:-1,1:-1]
        valid = (center > .3)&(center < 5)
        for neighbour in (depth[1:-1,2:],depth[1:-1,:-2],depth[2:,1:-1],depth[:-2,1:-1]):
            valid &= (neighbour > .3)&(np.abs(neighbour-center) < .05+.01*center)
        cross = np.cross(xyz[1:-1,2:]-xyz[1:-1,:-2],xyz[2:,1:-1]-xyz[:-2,1:-1])
        length = np.linalg.norm(cross,axis=-1)
        valid &= length > 1e-10
        normal[1:-1,1:-1][valid] = cross[valid]/length[valid,None]
        result[scale] = dict(vertices=xyz,normals=normal,camera=c,depth=depth)
    return result


def normal_equation(target, source, transform, scale):
    stride = 2 if scale == 1 else 1
    xyz = source['vertices'][::stride,::stride].reshape(-1,3)
    normals = source['normals'][::stride,::stride].reshape(-1,3)
    valid = np.sum(normals*normals,axis=1) > .25
    xyz,normals = xyz[valid],normals[valid]
    query = xyz@transform[:3,:3].T+transform[:3,3]
    transformed_normals = normals@transform[:3,:3].T
    c = target['camera']
    # Reject invalid Z before division or integer conversion.
    front = np.isfinite(query).all(axis=1)&(query[:,2] > .3)
    query,transformed_normals = query[front],transformed_normals[front]
    uf = c['fx']*query[:,0]/query[:,2]+c['cx']
    vf = c['fy']*query[:,1]/query[:,2]+c['cy']
    u,v = np.rint(uf),np.rint(vf)
    inside = (u >= 1)&(u < c['width']-1)&(v >= 1)&(v < c['height']-1)
    query,transformed_normals = query[inside],transformed_normals[inside]
    u,v = u[inside].astype(np.int64),v[inside].astype(np.int64)
    point = target['vertices'][v,u]
    normal = target['normals'][v,u]
    valid = ((np.sum(normal*normal,axis=1) > .25)
             &(np.linalg.norm(query-point,axis=1) < (.12 if scale == 4 else .08))
             &(np.sum(transformed_normals*normal,axis=1) > .8))
    query,point,normal = query[valid],point[valid],normal[valid]
    residual = np.sum(normal*(query-point),axis=1)
    jacobian = np.column_stack([normal,np.cross(query,normal)])
    weights = np.minimum(1.,.01/np.maximum(np.abs(residual),1e-15))
    h = jacobian.T@(weights[:,None]*jacobian)
    g = jacobian.T@(weights*residual)
    rms = float(np.sqrt(np.mean(residual*residual))) if len(residual) else 0.
    return dict(count=len(residual),rms_m=rms,h=h,g=g)


def compare_equation(actual, expected):
    require(type(actual['count']) is int and actual['count'] == expected['count'],'exact raw correspondence count')
    np.testing.assert_allclose(actual['h'],expected['h'],atol=1e-7,rtol=1e-10,
                               err_msg='raw-pixel normal matrix')
    np.testing.assert_allclose(actual['g'],expected['g'],atol=1e-9,rtol=1e-10,
                               err_msg='raw-pixel gradient')
    require(np.isfinite(actual['rms_m']) and abs(actual['rms_m']-expected['rms_m']) <= 1e-10,
            'raw-pixel residual RMS')


def raster(depth, weights, transform, camera):
    valid = (depth > .3)&(depth < 5)
    indices = np.flatnonzero(valid.ravel())
    query = vertices(depth,camera).reshape(-1,3)[indices]@transform[:3,:3].T+transform[:3,3]
    support = weights.ravel()[indices]
    stats = dict(source_valid=len(indices),projected=0,selected=0)
    front = np.isfinite(query).all(axis=1)&(query[:,2] > .3)&(query[:,2] < 5)
    query,support,indices = query[front],support[front],indices[front]
    x = np.rint(camera['fx']*query[:,0]/query[:,2]+camera['cx'])
    y = np.rint(camera['fy']*query[:,1]/query[:,2]+camera['cy'])
    inside = (x >= 0)&(x < camera['width'])&(y >= 0)&(y < camera['height'])
    cells = y[inside].astype(np.int64)*camera['width']+x[inside].astype(np.int64)
    z,support,indices = query[inside,2],support[inside],indices[inside]
    stats['projected'] = len(z)
    output = np.zeros(depth.size)
    output_weight = np.zeros(depth.size,dtype=np.uint8)
    # Explicit independent lexicographic selection: cell, axial Z, source index.
    order = np.lexsort((indices,z,cells))
    ordered_cells = cells[order]
    first = np.r_[True,ordered_cells[1:] != ordered_cells[:-1]] if len(order) else np.array([],dtype=bool)
    winners = order[first]
    output[cells[winners]],output_weight[cells[winners]] = z[winners],support[winners]
    stats['selected'] = len(winners)
    return output.reshape(depth.shape),output_weight.reshape(depth.shape),stats


def fuse(model, weights, raw, transform, camera):
    projected,present,stats = raster(raw,np.ones(raw.shape,dtype=np.uint8),transform,camera)
    valid = present > 0
    filled = valid&(weights == 0)
    averaged = valid&(weights > 0)&(np.abs(projected-model) < .03+.01*model)
    replaced = valid&(weights > 0)&~averaged&(projected < model-.03-.01*model)
    ignored = valid&~filled&~averaged&~replaced
    output = model.copy()
    support = weights.copy()
    prior = np.minimum(16,weights[averaged]).astype(float)
    output[averaged] = (prior*model[averaged]+projected[averaged])/(prior+1)
    support[averaged] = np.minimum(16,weights[averaged]+1)
    output[filled|replaced] = projected[filled|replaced]
    support[filled|replaced] = 1
    counts = dict(warp=None,measurement=stats,filled=int(filled.sum()),averaged=int(averaged.sum()),
                  replaced=int(replaced.sum()),ignored=int(ignored.sum()))
    return output,support,counts


def reconstruct_update(model, weights, raw, camera, update):
    """Validate all raw equations and rebuild the next model only after acceptance."""
    require(raw.shape == (camera['height'],camera['width']) and np.isfinite(raw).all()
            and np.all((raw >= 0)&(raw <= 100)),'bounded decoded depth')
    source = pyramid(raw,camera)
    if model is None:
        require(update['accepted'] and not update['iterations'],'valid first initialization')
        require(np.sum(np.sum(source[4]['normals']**2,axis=-1) > .25) >= 200,'initial surface support')
        return raw.copy(),(raw > .3).astype(np.uint8),dict(iterations=0,final_equations=0,model_replaced=False)
    target = pyramid(model,camera)
    for step in update['iterations']:
        scale = step['scale']
        expected = normal_equation(target[scale],source[scale],pose(step['before']),scale)
        compare_equation(step['equation'],expected)
    if not update['accepted']:
        require(update['fusion'] is None and update['first_from_current'] is None,'no rejected-state commit')
        return model,weights,dict(iterations=len(update['iterations']),final_equations=0,model_replaced=False)
    relative = pose(update['iterations'][-1]['after'])
    final = normal_equation(target[1],source[1],relative,1)
    compare_equation(update['final_equation'],final)
    warp = None
    if update['keyframe_replaced']:
        inverse = np.eye(4)
        inverse[:3,:3] = relative[:3,:3].T
        inverse[:3,3] = -relative[:3,:3].T@relative[:3,3]
        model,weights,warp = raster(model,weights,inverse,camera)
        relative = np.eye(4)
    result,support,counts = fuse(model,weights,raw,relative,camera)
    counts['warp'] = warp
    require(update['fusion'] == counts,'exact independently reconstructed raster/fusion categories')
    return result,support,dict(iterations=len(update['iterations']),final_equations=1,
                              model_replaced=update['keyframe_replaced'])
