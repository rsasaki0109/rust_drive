"""Evaluation transport and independent linear algebra for optional depth research."""
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
CAMERA = dict(width=640,height=480,fx=525.,fy=525.,cx=319.5,cy=239.5)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(body):
    return hashlib.sha256(body).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)
        stream.write('\n')


def fresh(path):
    path = path.absolute()
    require(not path.exists() and not path.is_symlink()
            and not any(p.is_symlink() for p in path.parents),'fresh real output directory required')
    path.mkdir(parents=True)
    return path


class Client:
    def __init__(self, binary, camera):
        self.process = subprocess.Popen([str(binary.absolute())],stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            require(self.send(dict(kind='Configure',camera=camera)) == dict(configured=True,schema_version=1),
                    'versioned configuration acknowledgment')
        except BaseException:
            self.abort()
            raise

    def send(self, value):
        body = json.dumps(value,separators=(',',':'),allow_nan=False)+'\n'
        require(len(body.encode()) <= 8*1024*1024,'bounded input message')
        self.process.stdin.write(body)
        self.process.stdin.flush()
        response = self.process.stdout.readline(1024*1024+1)
        require(response.endswith('\n') and len(response) <= 1024*1024,'bounded complete solver response')
        return json.loads(response)

    def frame(self, stamp, depth):
        return self.send(dict(kind='Frame',timestamp=stamp,depth_m=depth.ravel().tolist()))

    def finish(self):
        self.process.stdin.close()
        require(self.process.wait(timeout=30) == 0,'solver process completion')
        require(not self.process.stdout.read(1) and not self.process.stderr.read(1),'clean protocol footer')
        self.process.stdout.close()
        self.process.stderr.close()

    def abort(self):
        if self.process.poll() is None:
            self.process.kill()
        self.process.wait(timeout=30)
        for stream in (self.process.stdin,self.process.stdout,self.process.stderr):
            stream.close()


def pose(value):
    r = np.asarray(value['rotation'],dtype=float)
    t = np.asarray(value['translation'],dtype=float)
    require(r.shape == (3,3) and t.shape == (3,) and np.isfinite(r).all() and np.isfinite(t).all(),
            'finite pose layout')
    np.testing.assert_allclose(r.T@r,np.eye(3),atol=1e-8,rtol=0)
    require(abs(np.linalg.det(r)-1) <= 1e-8,'proper rotation')
    out = np.eye(4)
    out[:3,:3],out[:3,3] = r,t
    return out


def exp_rotation(vector):
    # Axis/angle outer-product form independent of Rust's skew-square expression.
    angle = np.linalg.norm(vector)
    if angle < 1e-14:
        return np.eye(3)
    a = vector/angle
    x,y,z = a
    cross = np.array([[0.,-z,y],[z,0.,-x],[-y,x,0.]])
    return np.cos(angle)*np.eye(3)+(1-np.cos(angle))*np.outer(a,a)+np.sin(angle)*cross


def audit_iterations(update):
    steps = update['iterations']
    require(len(steps) <= 22,'bounded geometric iteration count')
    previous = None
    levels = []
    for step in steps:
        level = step['scale']
        require(level in (4,2,1),'fixed pyramid level')
        levels.append(level)
        before,after = pose(step['before']),pose(step['after'])
        if previous is not None:
            np.testing.assert_allclose(before,previous,atol=1e-12,rtol=0)
        previous = after
        equation = step['equation']
        h,g = np.asarray(equation['h']),np.asarray(equation['g'])
        require(h.shape == (6,6) and g.shape == (6,) and np.isfinite(h).all()
                and np.isfinite(g).all() and equation['count'] >= 200
                and 0 <= equation['rms_m'] <= 1.,'finite supported normal equations')
        np.testing.assert_allclose(h,h.T,atol=1e-9,rtol=1e-12)
        scale = np.sqrt(np.diag(h))
        a = h/scale[:,None]/scale[None,:]
        eigen = np.linalg.eigvalsh(a)
        condition = eigen[-1]/eigen[0]
        require(eigen[0] > 0 and condition <= 1e6,'scaled SPD admission')
        np.testing.assert_allclose(condition,step['scaled_condition'],atol=1e-7,rtol=1e-8)
        expected = np.linalg.solve(a,-g/scale)/scale
        d = np.asarray(step['delta'])
        np.testing.assert_allclose(d,expected,atol=1e-10,rtol=1e-8)
        require(np.linalg.norm(d[:3]) <= .1 and np.linalg.norm(d[3:]) <= .15,'bounded increments')
        increment = np.eye(4)
        increment[:3,:3],increment[:3,3] = exp_rotation(d[3:]),d[:3]
        np.testing.assert_allclose(after,increment@before,atol=1e-11,rtol=0)
    require(levels == sorted(levels,reverse=True)
            and all(levels.count(s) <= cap for s,cap in ((4,10),(2,7),(1,5))), 'pyramid work caps')
    if update['accepted'] and steps:
        e = update['final_equation']
        require(e['count'] >= 200 and 0 <= e['rms_m'] <= .03,'returned-pose residual admission')
        fusion = update['fusion']
        stats = fusion['measurement']
        require(0 <= stats['selected'] <= stats['projected'] <= stats['source_valid'] <= 640*480,
                'raster count partition')
        require(stats['selected'] == sum(fusion[k] for k in ('filled','averaged','replaced','ignored')),
                'all selected depths retained in fusion accounting')
    return len(steps)
