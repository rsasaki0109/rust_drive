//! Measured keyframe intensity complements the fused depth surface. No labels.
use crate::multireference::Gray;
use crate::{Equation, H, Level, Pose, cross, dot, norm, sub};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Photometric {
    #[default]
    Disabled,
    Keyframe,
}

#[derive(Clone, Debug, Serialize)]
pub struct PhotoEquation {
    pub count: usize,
    pub rms_gray: Option<f64>,
    pub used: bool,
    pub scale_m2_per_gray2: f64,
    pub h: H,
    pub g: [f64; 6],
}
#[derive(Debug, Serialize)]
pub struct PhotoState {
    pub source_timestamp: f64,
    pub reference_timestamp: Option<f64>,
    pub phase_qualified: bool,
    pub fresh: bool,
}
pub(super) struct PhotoPair<'a> {
    pub target: &'a [Gray],
    pub source: &'a [Gray],
    pub enabled: bool,
}
impl PhotoPair<'_> {
    pub(super) fn equation(
        &self,
        target: &Level,
        source: &Level,
        pose: Pose,
        scale: usize,
    ) -> PhotoEquation {
        let mut out = PhotoEquation {
            count: 0,
            rms_gray: None,
            used: false,
            scale_m2_per_gray2: 0.005_f64.powi(2) / 100.,
            h: [[0.; 6]; 6],
            g: [0.; 6],
        };
        if !self.enabled {
            return out;
        }
        let level = match scale {
            4 => 0,
            2 => 1,
            _ => 2,
        };
        let stride = if scale == 1 { 2 } else { 1 };
        let mut squared = 0.;
        for y in (0..source.camera.height).step_by(stride) {
            for x in (0..source.camera.width).step_by(stride) {
                let i = y * source.camera.width + x;
                if dot(source.normals[i], source.normals[i]) <= 0.25 {
                    continue;
                }
                let q = pose.transform(source.vertices[i]);
                let Some(j) = target.camera.project(q, true) else {
                    continue;
                };
                let n = target.normals[j];
                if dot(n, n) <= 0.25
                    || norm(sub(q, target.vertices[j])) >= if scale == 4 { 0.12 } else { 0.08 }
                    || dot(pose.rotate(source.normals[i]), n) <= 0.8
                {
                    continue;
                }
                let c = target.camera;
                let z = q[2];
                let Some((value, gx, gy)) =
                    self.target[level].sample(c.fx * q[0] / z + c.cx, c.fy * q[1] / z + c.cy)
                else {
                    continue;
                };
                let residual = value - self.source[level].pixels[i];
                if residual.abs() >= 30. || gx.hypot(gy) < 1. {
                    continue;
                }
                let jacobian = image_jacobian(c, q, gx, gy);
                let weight = (1. - (residual / 30.).powi(2)).powi(2);
                for a in 0..6 {
                    out.g[a] += jacobian[a] * residual * weight;
                    for b in 0..6 {
                        out.h[a][b] += jacobian[a] * jacobian[b] * weight;
                    }
                }
                out.count += 1;
                squared += residual * residual;
            }
        }
        if out.count > 0 {
            out.rms_gray = Some((squared / out.count as f64).sqrt());
        }
        out.used = out.count >= 200;
        out
    }
}
fn image_jacobian(c: crate::Camera, q: [f64; 3], gx: f64, gy: f64) -> [f64; 6] {
    let z = q[2];
    let g = [
        gx * c.fx / z,
        gy * c.fy / z,
        -(gx * c.fx * q[0] + gy * c.fy * q[1]) / (z * z),
    ];
    let r = cross(q, g);
    [g[0], g[1], g[2], r[0], r[1], r[2]]
}

pub(super) fn combine(geometry: &Equation, photo: Option<&PhotoEquation>) -> (H, [f64; 6]) {
    let (mut h, mut g) = (geometry.h, geometry.g);
    if let Some(p) = photo
        && p.used
    {
        for a in 0..6 {
            g[a] += p.scale_m2_per_gray2 * p.g[a];
            for b in 0..6 {
                h[a][b] += p.scale_m2_per_gray2 * p.h[a][b];
            }
        }
    }
    (h, g)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Camera, ImageObservation, Tracker, TrackerConfig};
    fn camera() -> Camera {
        Camera {
            width: 160,
            height: 120,
            fx: 130.,
            fy: 130.,
            cx: 79.5,
            cy: 59.5,
        }
    }
    fn texture(c: Camera, transform: Pose) -> Vec<u8> {
        (0..c.width * c.height)
            .map(|i| {
                let p = transform.transform(c.point(i, 2.5));
                (128.
                    + 30. * (7. * p[0]).sin()
                    + 25. * (9. * p[1]).cos()
                    + 20. * (4. * p[0] + 5. * p[1]).sin())
                .round()
                .clamp(0., 255.) as u8
            })
            .collect()
    }
    #[test]
    fn measured_image_jacobian_matches_all_six_pose_directions() {
        let c = camera();
        let q = [0.17, -0.12, 2.3];
        let expected = image_jacobian(c, q, 2., 3.);
        let value = |delta: [f64; 6]| {
            let p = Pose::identity().increment(delta).transform(q);
            2. * (c.fx * p[0] / p[2] + c.cx) + 3. * (c.fy * p[1] / p[2] + c.cy)
        };
        for i in 0..6 {
            let mut a = [0.; 6];
            let mut b = [0.; 6];
            a[i] = 1e-7;
            b[i] = -1e-7;
            assert!(((value(a) - value(b)) / 2e-7 - expected[i]).abs() < 2e-6);
        }
    }
    #[test]
    fn textured_plane_recovers_motion_unobservable_from_depth() {
        let c = camera();
        let depth = vec![2.5; c.width * c.height];
        let transform = Pose::identity().increment([0.015, -0.01, 0., 0., 0., 0.01]);
        let first = texture(c, Pose::identity());
        let current = texture(c, transform);
        let mut geometry = Tracker::new(c).unwrap();
        assert!(geometry.step(1., &depth).accepted);
        assert!(!geometry.step(1.03, &depth).accepted);
        let mut tracker = Tracker::with_config(
            c,
            TrackerConfig {
                photometric: Photometric::Keyframe,
                ..TrackerConfig::default()
            },
        )
        .unwrap();
        assert!(
            tracker
                .step_with_image(
                    1.,
                    &depth,
                    Some(ImageObservation {
                        timestamp: 1.001,
                        gray: &first
                    })
                )
                .accepted
        );
        let result = tracker.step_with_image(
            1.03,
            &depth,
            Some(ImageObservation {
                timestamp: 1.031,
                gray: &current,
            }),
        );
        assert!(result.accepted, "{:?}", result.rejection);
        assert!(result.final_photometric.unwrap().used);
        let error = transform
            .inverse()
            .compose(result.first_from_current.unwrap());
        assert!(norm(error.translation) < 0.004 && error.angle() < 0.004);
    }
    #[test]
    fn repeated_rgb_adds_no_constraint_but_new_depth_can_update() {
        let c = camera();
        let depth: Vec<_> = (0..c.width * c.height)
            .map(|i| {
                2. + 0.2 * ((i % c.width) as f64 * 0.07).sin() * ((i / c.width) as f64 * 0.09).sin()
            })
            .collect();
        let gray = texture(c, Pose::identity());
        let mut tracker = Tracker::with_config(
            c,
            TrackerConfig {
                photometric: Photometric::Keyframe,
                ..TrackerConfig::default()
            },
        )
        .unwrap();
        assert!(
            tracker
                .step_with_image(
                    1.,
                    &depth,
                    Some(ImageObservation {
                        timestamp: 1.001,
                        gray: &gray
                    })
                )
                .accepted
        );
        let repeated = tracker.step_with_image(
            1.004,
            &depth,
            Some(ImageObservation {
                timestamp: 1.001,
                gray: &gray,
            }),
        );
        assert!(repeated.accepted);
        assert!(!repeated.photometric.unwrap().fresh);
        let e = repeated.final_photometric.unwrap();
        assert_eq!(e.count, 0);
        assert!(!e.used);
        assert!(
            !tracker
                .step_with_image(
                    1.004,
                    &depth,
                    Some(ImageObservation {
                        timestamp: 1.001,
                        gray: &gray
                    })
                )
                .accepted
        );
        assert!(!tracker.step_with_image(1.01, &depth, None).accepted);
        assert_eq!(tracker.last_accepted, Some(1.004));
        assert!(
            !tracker
                .step_with_image(
                    1.02,
                    &depth,
                    Some(ImageObservation {
                        timestamp: 1.,
                        gray: &gray
                    })
                )
                .accepted
        );
        assert_eq!(tracker.last_accepted, Some(1.004));
        assert!(
            tracker
                .step_with_image(
                    1.03,
                    &depth,
                    Some(ImageObservation {
                        timestamp: 1.031,
                        gray: &gray
                    })
                )
                .accepted
        );
    }
}
